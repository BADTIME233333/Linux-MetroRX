import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts

ApplicationWindow {
    id: root

    width: 1280
    height: 800
    minimumWidth: 760
    minimumHeight: 560
    visible: true
    title: "Metro Touch Shell"
    color: "#08668f"

    property int selectedTileIndex: -1
    property bool selectionMode: false
    property int currentPage: Math.round(pageScroller.contentX / Math.max(1, pageScroller.width))
    property string currentTime: Qt.formatDateTime(new Date(), "hh:mm")
    property int draggingTileIndex: -1
    property bool tileMoveActive: false
    property string resizeEdge: ""
    property real dragVisualX: 0
    property real dragVisualY: 0
    property real dragGrabX: 0
    property real dragGrabY: 0
    property int previewPage: -1
    property int previewColumn: -1
    property int previewRow: -1
    property int resizeStartPage: 0
    property int resizeStartColumn: 0
    property int resizeStartRow: 0
    property int resizeStartColumns: 1
    property int resizeStartRows: 1
    property real resizeStartX: 0
    property real resizeStartY: 0

    focus: true

    Keys.onEscapePressed: {
        root.cancelSelectionMode()
    }

    function cancelSelectionMode() {
        if (draggingTileIndex >= 0)
            tileStore.cancelTileEdit()
        draggingTileIndex = -1
        tileMoveActive = false
        resizeEdge = ""
        if (tileActionMenu.visible)
            tileActionMenu.close()
        selectedTileIndex = -1
        selectionMode = false
    }

    function openTileActionMenu(index, screenX, screenY) {
        if (tileActionMenu.visible)
            tileActionMenu.close()
        selectedTileIndex = index
        const position = Overlay.overlay.mapFromItem(root, screenX, screenY)
        tileActionMenu.requestedX = position.x + tileActionMenu.width + 28
                > Overlay.overlay.width ? position.x - tileActionMenu.width - 28
                                         : position.x + 28
        tileActionMenu.requestedY = position.y - tileActionMenu.height / 2
        tileActionMenu.open()
    }

    function tileIndexAt(screenX, screenY) {
        const position = tileWall.mapFromItem(root, screenX, screenY)
        const cellWidth = pageScroller.width / 10
        const cellHeight = pageScroller.height / 10
        const tiles = tileStore.tiles
        for (let i = 0; i < tiles.length; ++i) {
            const tile = tiles[i]
            const width = tile.columns * cellWidth - 12
            const height = tile.rows * cellHeight - 12
            const baseX = tile.page * pageScroller.width + tile.column * cellWidth + 6
                    + width * (1 - 0.88) / 2
            const baseY = tile.row * cellHeight + 6 + height * (1 - 0.88) / 2
            if (position.x >= baseX && position.x <= baseX + width * 0.88
                    && position.y >= baseY && position.y <= baseY + height * 0.88) {
                return i
            }
        }
        return -1
    }

    function selectTileAt(screenX, screenY) {
        const index = tileIndexAt(screenX, screenY)
        if (index >= 0)
            openTileActionMenu(index, screenX, screenY)
    }

    function startTileMove(index, sceneX, sceneY) {
        if (!selectionMode || selectedTileIndex !== index || tileActionMenu.visible)
            return
        if (!tileStore.beginTileEdit(index))
            return
        const tile = tileStore.tiles[index]
        const cellWidth = pageScroller.width / 10
        const cellHeight = pageScroller.height / 10
        const pointer = tileWall.mapFromItem(null, sceneX, sceneY)
        tileMoveActive = true
        draggingTileIndex = index
        dragVisualX = tile.page * pageScroller.width + tile.column * cellWidth + 6
        dragVisualY = tile.row * cellHeight + 6
        dragGrabX = pointer.x - dragVisualX
        dragGrabY = pointer.y - dragVisualY
        previewPage = tile.page
        previewColumn = tile.column
        previewRow = tile.row
    }

    function updateTileMove(sceneX, sceneY) {
        if (draggingTileIndex < 0 || !tileMoveActive)
            return
        const pointer = tileWall.mapFromItem(null, sceneX, sceneY)
        dragVisualX = pointer.x - dragGrabX
        dragVisualY = pointer.y - dragGrabY
        const width = pageScroller.width
        const cellWidth = width / 10
        const cellHeight = pageScroller.height / 10
        const tile = tileStore.tiles[draggingTileIndex]
        const page = Math.max(0, Math.min(1, Math.floor((pointer.x - dragGrabX
                                                        + cellWidth * tile.columns / 2) / width)))
        const column = Math.max(0, Math.min(10 - tile.columns,
                                            Math.round((dragVisualX - page * width - 6) / cellWidth)))
        const row = Math.max(0, Math.min(10 - tile.rows,
                                         Math.round((dragVisualY - 6) / cellHeight)))
        if (page === previewPage && column === previewColumn && row === previewRow)
            return
        if (tileStore.previewTilePlacement(draggingTileIndex, page, column, row,
                                           tile.columns, tile.rows)) {
            previewPage = page
            previewColumn = column
            previewRow = row
        } else {
            notice.text = "附近没有可用空位，磁贴保持在上一个有效位置。"
        }
    }

    function finishTileMove(sceneX, sceneY) {
        if (draggingTileIndex < 0 || !tileMoveActive)
            return
        updateTileMove(sceneX, sceneY)
        if (tileStore.finishTileEdit())
            notice.text = "磁贴位置已保存。"
        draggingTileIndex = -1
        tileMoveActive = false
    }

    function startTileResize(index, edge, sceneX, sceneY) {
        if (!selectionMode || selectedTileIndex !== index || tileActionMenu.visible)
            return
        if (!tileStore.beginTileEdit(index))
            return
        const pointer = tileWall.mapFromItem(null, sceneX, sceneY)
        const tile = tileStore.tiles[index]
        resizeEdge = edge
        draggingTileIndex = index
        tileMoveActive = false
        resizeStartX = pointer.x
        resizeStartY = pointer.y
        resizeStartPage = tile.page
        resizeStartColumn = tile.column
        resizeStartRow = tile.row
        resizeStartColumns = tile.columns
        resizeStartRows = tile.rows
        previewPage = tile.page
        previewColumn = tile.column
        previewRow = tile.row
    }

    function updateTileResize(edge, sceneX, sceneY) {
        if (draggingTileIndex < 0 || resizeEdge !== edge)
            return
        const pointer = tileWall.mapFromItem(null, sceneX, sceneY)
        const deltaColumns = Math.round((pointer.x - resizeStartX) / (pageScroller.width / 10))
        const deltaRows = Math.round((pointer.y - resizeStartY) / (pageScroller.height / 10))
        let column = resizeStartColumn
        let row = resizeStartRow
        let columns = resizeStartColumns
        let rows = resizeStartRows
        if (edge.endsWith("Left")) {
            const applied = Math.max(1 - columns, Math.min(column, deltaColumns))
            column += applied
            columns -= applied
        } else if (edge.endsWith("Right")) {
            columns = Math.max(1, Math.min(10 - column, columns + deltaColumns))
        }
        if (edge.startsWith("top")) {
            const applied = Math.max(1 - rows, Math.min(row, deltaRows))
            row += applied
            rows -= applied
        } else if (edge.startsWith("bottom")) {
            rows = Math.max(1, Math.min(10 - row, rows + deltaRows))
        }
        if (column === previewColumn && row === previewRow
                && columns === tileStore.tiles[draggingTileIndex].columns
                && rows === tileStore.tiles[draggingTileIndex].rows)
            return
        if (tileStore.previewTilePlacement(draggingTileIndex, resizeStartPage,
                                           column, row, columns, rows)) {
            previewPage = resizeStartPage
            previewColumn = column
            previewRow = row
        } else {
            notice.text = "这个尺寸附近没有足够空位，磁贴保持在上一个有效尺寸。"
        }
    }

    function finishTileResize(edge, sceneX, sceneY) {
        if (draggingTileIndex < 0 || resizeEdge !== edge)
            return
        updateTileResize(edge, sceneX, sceneY)
        if (tileStore.finishTileEdit())
            notice.text = "磁贴尺寸和避让布局已保存。"
        draggingTileIndex = -1
        resizeEdge = ""
    }

    Timer {
        interval: 15000
        repeat: true
        running: true
        onTriggered: root.currentTime = Qt.formatDateTime(new Date(), "hh:mm")
    }

    Item {
        id: desktopContent
        anchors.fill: parent

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#0785a5" }
            GradientStop { position: 0.48; color: "#086c9c" }
            GradientStop { position: 1.0; color: "#124a83" }
        }

        Item {
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            width: Math.min(parent.width * 0.4, 470)
            height: width * 0.58
            opacity: 0.065

            Rectangle {
                x: 0; y: 0; width: parent.width * 0.48; height: parent.height * 0.46
                color: "white"
            }
            Rectangle {
                x: parent.width * 0.52; y: 0
                width: parent.width * 0.48; height: parent.height * 0.46
                color: "white"
            }
            Rectangle {
                x: 0; y: parent.height * 0.54
                width: parent.width * 0.48; height: parent.height * 0.46
                color: "white"
            }
            Rectangle {
                x: parent.width * 0.52; y: parent.height * 0.54
                width: parent.width * 0.48; height: parent.height * 0.46
                color: "white"
            }
        }
    }

    Item {
        id: topBar
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        height: 126

        TapHandler {
            enabled: root.selectionMode
            onTapped: {
                if (root.selectionMode)
                    root.cancelSelectionMode()
            }
        }

        Row {
            id: titleGroup
            anchors.left: parent.left
            anchors.leftMargin: 42
            anchors.top: parent.top
            anchors.topMargin: 19
            spacing: 13

            Text {
                id: pageTitle
                text: root.selectionMode ? "编辑磁贴" : "主页"
                color: "white"
                font.family: "sans-serif"
                font.pixelSize: 47
                font.weight: Font.Light
                renderType: Text.NativeRendering
                Accessible.role: Accessible.Heading
            }

            Text {
                anchors.baseline: pageTitle.baseline
                text: "start"
                color: "#d9ffffff"
                font.pixelSize: 16
                font.weight: Font.Light
            }
        }

        ToolButton {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: 17
            width: 42
            height: 42
            text: "⌄"
            font.pixelSize: 22
            palette.buttonText: "white"
            background: Rectangle { color: "transparent" }
            Accessible.name: "向下菜单（原型占位）"
            onClicked: notice.text = "向下箭头功能尚未实现。"
        }

        Row {
            id: systemInfo
            anchors.right: parent.right
            anchors.rightMargin: 38
            anchors.top: parent.top
            anchors.topMargin: 30
            spacing: 14

            Text {
                text: root.currentTime
                color: "white"
                font.pixelSize: 15
                anchors.verticalCenter: parent.verticalCenter
            }

            Text {
                text: "⌁"
                color: "white"
                font.pixelSize: 19
                anchors.verticalCenter: parent.verticalCenter
                Accessible.name: "网络状态演示"
            }

            Rectangle {
                width: 28
                height: 28
                radius: 14
                color: "#72ffffff"
                anchors.verticalCenter: parent.verticalCenter

                Text {
                    anchors.centerIn: parent
                    text: "用"
                    color: "white"
                    font.pixelSize: 12
                }
            }

            Column {
                spacing: 1
                anchors.verticalCenter: parent.verticalCenter

                Text {
                    text: "桌面用户"
                    color: "white"
                    font.pixelSize: 12
                }
                Text {
                    text: "本地原型"
                    color: "#bfe9f5"
                    font.pixelSize: 10
                }
            }
        }

    }

    Flickable {
        id: pageScroller
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: topBar.bottom
        anchors.bottom: pageFooter.top
        clip: true
        contentWidth: width * 2
        contentHeight: height
        boundsBehavior: Flickable.StopAtBounds
        flickDeceleration: 1800
        maximumFlickVelocity: 2600
        snapMode: Flickable.NoSnap
        interactive: !root.selectionMode
        pressDelay: 0
        property real previousViewportWidth: 0
        onWidthChanged: {
            if (previousViewportWidth > 0)
                contentX = contentX / previousViewportWidth * width
            previousViewportWidth = width
        }
        Component.onCompleted: previousViewportWidth = width

        TapHandler {
            enabled: root.selectionMode
            onTapped: {
                const position = pageScroller.mapToItem(root,
                                                        point.position.x,
                                                        point.position.y)
                if (root.tileIndexAt(position.x, position.y) < 0)
                    root.cancelSelectionMode()
            }
        }

        Item {
            id: tileWall
            width: pageScroller.contentWidth
            height: pageScroller.height
            x: pageScroller.width * 0.38
            opacity: 0

            Repeater {
                model: tileStore.tileModel

                delegate: TileCard {
                    id: tileCard
                    required property int index
                    required property var tile

                    tileData: tile
                    tileIndex: index
                    selectionMode: root.selectionMode
                    pageActive: tile.page === root.currentPage
                    sideMenuOpen: tileActionMenu.visible && root.selectedTileIndex === index
                    moveEnabled: root.selectionMode && root.selectedTileIndex === index
                    resizeEnabled: root.selectionMode && root.selectedTileIndex === index
                    cellWidth: pageScroller.width / 10
                    cellHeight: pageScroller.height / 10
                    x: root.draggingTileIndex === index && root.tileMoveActive
                       ? root.dragVisualX
                       : tile.page * pageScroller.width + tile.column * cellWidth + 6
                    y: root.draggingTileIndex === index && root.tileMoveActive
                       ? root.dragVisualY : tile.row * cellHeight + 6
                    width: tile.columns * cellWidth - 12
                    height: tile.rows * cellHeight - 12

                    Behavior on x {
                        enabled: root.draggingTileIndex !== index || !root.tileMoveActive
                        NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
                    }
                    Behavior on y {
                        enabled: root.draggingTileIndex !== index || !root.tileMoveActive
                        NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
                    }

                    Behavior on width {
                        enabled: root.draggingTileIndex !== index || root.resizeEdge.length > 0
                        NumberAnimation {
                            duration: 240
                            easing.type: Easing.Bezier
                            easing.bezierCurve: [0.18, 0.67, 0.2, 1.0, 1.0, 1.0]
                        }
                    }
                    Behavior on height {
                        enabled: root.draggingTileIndex !== index || root.resizeEdge.length > 0
                        NumberAnimation {
                            duration: 240
                            easing.type: Easing.Bezier
                            easing.bezierCurve: [0.18, 0.67, 0.2, 1.0, 1.0, 1.0]
                        }
                    }

                    onLongPressStarted: {
                        root.selectionMode = true
                        root.selectedTileIndex = index
                    }
                    onHoldReleased: function(x, y) {
                        const position = root.mapFromItem(tileCard, x, y)
                        root.selectTileAt(position.x, position.y)
                    }
                    onTapped: {
                        if (!root.selectionMode) {
                            notice.text = "应用启动尚未接入。"
                            return
                        }
                        if (tileActionMenu.visible && root.selectedTileIndex === index) {
                            tileActionMenu.close()
                            return
                        }
                        const position = tileCard.mapToItem(root, tileCard.width / 2,
                                                           tileCard.height / 2)
                        root.openTileActionMenu(index, position.x, position.y)
                    }
                    onMediaLoadFailed: notice.text = message
                    onMoveStarted: root.startTileMove(index, sceneX, sceneY)
                    onMoveUpdated: root.updateTileMove(sceneX, sceneY)
                    onMoveFinished: root.finishTileMove(sceneX, sceneY)
                    onResizeStarted: function(edge, sceneX, sceneY) {
                        root.startTileResize(index, edge, sceneX, sceneY)
                    }
                    onResizeUpdated: function(edge, sceneX, sceneY) {
                        root.updateTileResize(edge, sceneX, sceneY)
                    }
                    onResizeFinished: function(edge, sceneX, sceneY) {
                        root.finishTileResize(edge, sceneX, sceneY)
                    }
                }
            }
        }
    }

    Item {
        id: pageFooter
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: 58

        TapHandler {
            enabled: root.selectionMode
            onTapped: {
                const localPoint = backgroundButton.mapFromItem(pageFooter,
                                                                 point.position.x,
                                                                 point.position.y)
                if (root.selectionMode && !backgroundButton.contains(localPoint))
                    root.cancelSelectionMode()
            }
        }

        Text {
            anchors.right: parent.right
            anchors.rightMargin: 38
            anchors.verticalCenter: parent.verticalCenter
            text: root.selectionMode ? "拖动磁贴移动 · 拖动四角调整大小 · 点空白处退出"
                                     : "左右滑动浏览磁贴"
            color: "#d8ffffff"
            font.pixelSize: 12
        }

        Text {
            id: notice
            anchors.left: parent.left
            anchors.leftMargin: 38
            anchors.verticalCenter: parent.verticalCenter
            text: ""
            color: "#fff3c4"
            font.pixelSize: 12
            elide: Text.ElideRight
            width: parent.width * 0.38
        }

        MetroButton {
            id: backgroundButton
            anchors.left: parent.left
            anchors.leftMargin: 34
            anchors.verticalCenter: parent.verticalCenter
            visible: root.selectionMode
            text: "自定义背景"
            restingColor: "#dce8edf2"
            pressedColor: "#171a1d"
            restingTextColor: "#151515"
            pressedTextColor: "white"
            onClicked: notice.text = "桌面背景自定义入口已预留，当前版本尚未接入。"
        }
    }
    }

    TileActionMenu {
        id: tileActionMenu
        tileIndex: root.selectedTileIndex
        backdropSource: desktopContent

        onEditAppearance: {
            appearanceEditor.open()
        }
        onChooseCustomContent: customContentPicker.open()
    }

    TileAppearanceEditor {
        id: appearanceEditor
        tileIndex: root.selectedTileIndex
    }

    FileDialog {
        id: customContentPicker
        title: "选择磁贴图片或视频"
        nameFilters: [
            "图片和视频 (*.png *.jpg *.jpeg *.webp *.bmp *.gif *.mp4 *.webm *.mkv *.mov)",
            "所有文件 (*)"
        ]
        fileMode: FileDialog.OpenFile
        onAccepted: {
            const source = selectedFile.toString()
            const isVideo = /\.(mp4|webm|mkv|mov)(\?.*)?$/i.test(source)
            if (tileStore.updateTile(root.selectedTileIndex, {
                liveEnabled: false,
                customContentMode: isVideo ? "video" : "image",
                customContentSource: source,
                videoLoop: true
            })) {
                notice.text = isVideo ? "自定义视频磁贴已启用（默认循环播放）。"
                                      : "自定义图片磁贴已启用。"
            }
            root.cancelSelectionMode()
        }
    }

    Timer {
        interval: 450
        running: true
        onTriggered: wallEntrance.start()
    }

    ParallelAnimation {
        id: wallEntrance
        NumberAnimation {
            target: tileWall
            property: "x"
            to: 0
            duration: 620
            easing.type: Easing.OutCubic
        }
        NumberAnimation {
            target: tileWall
            property: "opacity"
            to: 1
            duration: 620
            easing.type: Easing.OutCubic
        }
    }

    Connections {
        target: tileStore
        function onOperationFailed(message) {
            notice.text = message
        }
    }
}
