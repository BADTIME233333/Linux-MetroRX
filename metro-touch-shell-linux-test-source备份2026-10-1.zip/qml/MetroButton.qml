import QtQuick
import QtQuick.Controls
import QtQuick.Effects

Button {
    id: control

    property color restingTextColor: "#151515"
    property color pressedTextColor: "white"
    property color restingColor: "#dce9edf0"
    property color pressedColor: "#171a1d"
    property color selectedColor: "#171a1d"
    property color disabledColor: "#bfc1c3"
    implicitHeight: 46

    background: Item {
        MultiEffect {
            anchors.fill: parent
            source: buttonFace
            shadowEnabled: control.enabled && !control.down && !control.highlighted
            shadowColor: "#78000000"
            shadowOpacity: 0.55
            shadowBlur: 0.28
            shadowHorizontalOffset: 1
            shadowVerticalOffset: 3
        }

        Rectangle {
            id: buttonFace
            anchors.fill: parent
            color: !control.enabled ? control.disabledColor
                  : control.down ? control.pressedColor
                  : control.highlighted ? control.selectedColor
                  : control.hovered ? "#eef7f8f9" : control.restingColor
            border.color: control.down || control.highlighted ? "#080a0c" : "#75ffffff"
            border.width: 1
            radius: 0
        }

        Rectangle {
            anchors.fill: parent
            visible: control.down || control.highlighted
            color: "transparent"
            border.color: "#59000000"
            border.width: 2
        }
    }

    contentItem: Text {
        text: control.text
        color: !control.enabled ? "#777777"
              : control.down || control.highlighted ? control.pressedTextColor
              : control.restingTextColor
        font: control.font
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
}
