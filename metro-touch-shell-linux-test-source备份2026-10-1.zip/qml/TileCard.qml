import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtMultimedia

Item {
    id: root

    required property var tileData
    required property int tileIndex
    required property real cellWidth
    required property real cellHeight
    signal longPressStarted()
    signal holdReleased(real x, real y)
    signal tapped()
    signal mediaLoadFailed(string message)
    signal moveStarted(real sceneX, real sceneY)
    signal moveUpdated(real sceneX, real sceneY)
    signal moveFinished(real sceneX, real sceneY)
    signal resizeStarted(string edge, real sceneX, real sceneY)
    signal resizeUpdated(string edge, real sceneX, real sceneY)
    signal resizeFinished(string edge, real sceneX, real sceneY)
    property bool selectionMode: false
    property bool longPressTriggered: false
    property bool pageActive: false
    property bool sideMenuOpen: false
    property bool moveEnabled: false
    property bool resizeEnabled: false

    Accessible.name: "自定义磁贴 " + tileData.title
    Accessible.description: tileData.subtitle
    Accessible.role: Accessible.Button

    property int liveItemIndex: 0
    property bool compact: width < 155 || height < 125
    property real tileCornerRadius: {
        switch (tileData.cornerPreset) {
        case "square": return 0
        case "micro": return 5
        case "natural": return 12
        case "medium": return 20
        case "high": return 30
        case "circle": return Math.min(width, height) / 2
        default: return 0
        }
    }

    function traceRoundedRect(context, x, y, width, height, radius) {
        const corner = Math.max(0, Math.min(radius, width / 2, height / 2))
        context.beginPath()
        context.moveTo(x + corner, y)
        context.lineTo(x + width - corner, y)
        context.quadraticCurveTo(x + width, y, x + width, y + corner)
        context.lineTo(x + width, y + height - corner)
        context.quadraticCurveTo(x + width, y + height, x + width - corner, y + height)
        context.lineTo(x + corner, y + height)
        context.quadraticCurveTo(x, y + height, x, y + height - corner)
        context.lineTo(x, y + corner)
        context.quadraticCurveTo(x, y, x + corner, y)
        context.closePath()
    }

    scale: selectionMode ? 0.88 : 1.0

    implicitWidth: cellWidth * tileData.columns
    implicitHeight: cellHeight * tileData.rows

    Behavior on scale {
        NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
    }

    onPageActiveChanged: {
        if (pageActive && tileData.customContentMode === "video")
            tileVideo.play()
        else
            tileVideo.pause()
    }

    Timer {
        interval: 4500
        repeat: true
        running: root.tileData.liveEnabled && root.tileData.liveItems.length > 1
        onTriggered: root.liveItemIndex = (root.liveItemIndex + 1) % root.tileData.liveItems.length
    }

    Item {
        id: outerShadow
        anchors.fill: parent
        visible: root.tileData.shadowMode === "outer" || root.tileData.shadowMode === "soft"
                 || root.tileData.shadowMode === "both"
        z: -1

        Rectangle {
            id: shadowMask
            width: root.width
            height: root.height
            radius: root.tileCornerRadius
            color: "white"
        }

        MultiEffect {
            x: -14
            y: -14
            width: parent.width + 28
            height: parent.height + 28
            source: shadowMask
            shadowEnabled: true
            shadowColor: "#77000000"
            shadowOpacity: 0.72
            shadowBlur: 0.68
            shadowHorizontalOffset: 7
            shadowVerticalOffset: 8
            autoPaddingEnabled: false
        }
    }

    Rectangle {
        id: surface
        anchors.fill: parent
        radius: root.tileCornerRadius
        color: "transparent"
        clip: true

        Image {
            anchors.fill: parent
            source: root.tileData.customContentMode === "image"
                    ? root.tileData.customContentSource : root.tileData.imageSource
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            visible: source.toString().length > 0
            opacity: root.tileData.opacity * 0.82
            onStatusChanged: {
                if (status === Image.Error && root.tileData.customContentMode === "image")
                    root.mediaLoadFailed("图片无法读取：" + root.tileData.title)
            }
        }

        VideoOutput {
            id: videoOutput
            anchors.fill: parent
            visible: root.tileData.customContentMode === "video" && root.pageActive
            fillMode: VideoOutput.PreserveAspectCrop
            opacity: root.tileData.opacity * 0.82
        }

        MediaPlayer {
            id: tileVideo
            source: root.tileData.customContentMode === "video" && root.pageActive
                    ? root.tileData.customContentSource : ""
            videoOutput: videoOutput
            loops: root.tileData.videoLoop ? MediaPlayer.Infinite : 1
            onSourceChanged: {
                if (source.toString().length > 0)
                    play()
            }
            onErrorOccurred: function(error, errorString) {
                root.mediaLoadFailed("视频无法播放：" + errorString)
            }
        }

        Repeater {
            model: root.tileData.layers

            delegate: ColorLayer {
                required property var modelData
                anchors.fill: parent
                layerData: modelData
                cornerRadius: root.tileCornerRadius
                tileOpacity: root.tileData.opacity
            }
        }

        Canvas {
            id: insetShadow
            anchors.fill: parent
            visible: root.tileData.shadowMode === "inset" || root.tileData.shadowMode === "both"
            property real cornerRadius: root.tileCornerRadius

            onWidthChanged: requestPaint()
            onHeightChanged: requestPaint()
            onCornerRadiusChanged: requestPaint()
            onVisibleChanged: {
                if (visible)
                    requestPaint()
            }

            onPaint: {
                const context = getContext("2d")
                context.clearRect(0, 0, width, height)
                if (width <= 0 || height <= 0)
                    return

                const extent = 9
                context.save()
                root.traceRoundedRect(context, 0, 0, width, height, cornerRadius)
                context.clip()
                context.lineWidth = extent * 2
                context.shadowBlur = 9
                context.shadowColor = "rgba(0, 0, 0, 0.48)"
                context.shadowOffsetX = extent / 2
                context.shadowOffsetY = extent / 2
                context.strokeStyle = "rgba(0, 0, 0, 0.4)"
                root.traceRoundedRect(context, -extent, -extent,
                                      width + extent * 2, height + extent * 2,
                                      cornerRadius + extent)
                context.stroke()

                context.shadowColor = "rgba(255, 255, 255, 0.62)"
                context.shadowOffsetX = -extent / 2
                context.shadowOffsetY = -extent / 2
                context.strokeStyle = "rgba(255, 255, 255, 0.38)"
                root.traceRoundedRect(context, -extent, -extent,
                                      width + extent * 2, height + extent * 2,
                                      cornerRadius + extent)
                context.stroke()
                context.restore()
            }
        }

        Column {
            anchors.fill: parent
            anchors.margins: root.compact ? 11 : 17
            spacing: root.compact ? 5 : 9

            Item {
                width: root.compact ? 35 : 48
                height: root.compact ? 35 : 48

                Image {
                    anchors.fill: parent
                    source: root.tileData.iconSource
                    fillMode: Image.PreserveAspectFit
                    asynchronous: true
                    visible: source.toString().length > 0
                    onStatusChanged: {
                        if (status === Image.Error)
                            root.mediaLoadFailed("图标图片无法读取：" + root.tileData.title)
                    }
                }

                Text {
                    anchors.fill: parent
                    text: root.tileData.icon
                    color: "white"
                    font.pixelSize: root.compact ? 27 : Math.min(42, root.height * 0.23)
                    font.weight: Font.Light
                    renderType: Text.NativeRendering
                    verticalAlignment: Text.AlignVCenter
                    visible: root.tileData.iconSource.length === 0
                }
            }

            Item {
                width: 1
                height: Math.max(0, root.height - titleLabel.height - parent.spacing * 2
                                 - (root.compact ? 35 : 55))
                visible: !root.compact && root.height > 175
            }

            Text {
                id: titleLabel
                width: parent.width
                text: root.tileData.title
                color: "white"
                font.pixelSize: root.compact ? 15 : 19
                font.weight: Font.Medium
                elide: Text.ElideRight
                maximumLineCount: 1
            }

            Text {
                width: parent.width
                text: root.tileData.liveEnabled && root.tileData.liveItems.length > 0
                      ? root.tileData.liveItems[root.liveItemIndex]
                      : root.tileData.subtitle
                color: "#e7ffffff"
                font.pixelSize: root.compact ? 11 : 13
                elide: Text.ElideRight
                maximumLineCount: 1
                visible: root.height > 100
            }
        }

        Repeater {
            model: root.resizeEnabled && !root.sideMenuOpen
                   ? ["topLeft", "topRight", "bottomLeft", "bottomRight"] : []

            delegate: Rectangle {
                id: resizeHandle
                required property string modelData
                x: modelData.endsWith("Left") ? 0 : root.width - width
                y: modelData.startsWith("top") ? 0 : root.height - height
                width: 17
                height: 17
                radius: 0
                color: "#f4ffffff"
                border.color: "#008cf0"
                border.width: 1
                z: 5

                DragHandler {
                    target: null
                    acceptedButtons: Qt.LeftButton
                    acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchScreen
                    onActiveChanged: {
                        if (active)
                            root.resizeStarted(resizeHandle.modelData,
                                               centroid.scenePosition.x,
                                               centroid.scenePosition.y)
                        else
                            root.resizeFinished(resizeHandle.modelData,
                                                centroid.scenePosition.x,
                                                centroid.scenePosition.y)
                    }
                    onCentroidChanged: {
                        if (active)
                            root.resizeUpdated(resizeHandle.modelData,
                                               centroid.scenePosition.x,
                                               centroid.scenePosition.y)
                    }
                }
            }

        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 5
            width: sizeLabel.implicitWidth + 18
            height: 24
            radius: 0
            color: "#0078d4"
            visible: root.resizeEnabled && !root.sideMenuOpen
            z: 6

            Text {
                id: sizeLabel
                anchors.centerIn: parent
                text: Math.round(root.width) + " × " + Math.round(root.height)
                color: "white"
                font.pixelSize: 13
            }
        }

        TapHandler {
            acceptedButtons: Qt.LeftButton
            gesturePolicy: TapHandler.DragThreshold
            longPressThreshold: 0.5
            onLongPressed: {
                root.longPressTriggered = true
                root.longPressStarted()
            }
            onPressedChanged: {
                if (pressed)
                    root.longPressTriggered = false
                if (!pressed && root.selectionMode && root.longPressTriggered) {
                    root.holdReleased(point.position.x, point.position.y)
                }
            }
            onTapped: {
                if (!root.longPressTriggered)
                    root.tapped()
                root.longPressTriggered = false
            }
        }

        DragHandler {
            target: null
            enabled: root.moveEnabled && !root.sideMenuOpen && !root.longPressTriggered
            acceptedButtons: Qt.LeftButton
            acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchScreen
            onActiveChanged: {
                if (active)
                    root.moveStarted(centroid.scenePosition.x, centroid.scenePosition.y)
                else
                    root.moveFinished(centroid.scenePosition.x, centroid.scenePosition.y)
            }
            onCentroidChanged: {
                if (active)
                    root.moveUpdated(centroid.scenePosition.x, centroid.scenePosition.y)
            }
        }
    }
}
