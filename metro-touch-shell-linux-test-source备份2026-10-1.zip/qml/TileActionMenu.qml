import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.Layouts

Popup {
    id: root

    required property int tileIndex
    required property Item backdropSource
    property real requestedX: 0
    property real requestedY: 0
    signal editAppearance()
    signal chooseCustomContent()

    parent: Overlay.overlay
    width: 326
    height: menuColumn.implicitHeight + 18
    padding: 8
    modal: false
    focus: true
    closePolicy: Popup.CloseOnEscape
    x: Math.max(12, Math.min(parent.width - width - 12, requestedX))
    y: Math.max(12, Math.min(parent.height - height - 12, requestedY))

    onOpened: {
        unfoldScale.yScale = 0.12
        menuReveal.restart()
    }

    background: Item {
        clip: true

        property point captureOrigin: Overlay.overlay.mapToItem(root.backdropSource,
                                                               root.x, root.y)

        ShaderEffectSource {
            id: backdropCapture
            anchors.fill: parent
            sourceItem: root.backdropSource
            sourceRect: Qt.rect(parent.captureOrigin.x, parent.captureOrigin.y,
                                width, height)
            textureSize: Qt.size(Math.round(width * 1.5), Math.round(height * 1.5))
            live: true
            recursive: false
            z: -1
        }

        MultiEffect {
            anchors.fill: parent
            source: backdropCapture
            blurEnabled: true
            blur: 0.85
            blurMax: 40
            autoPaddingEnabled: false
        }

        Rectangle {
            anchors.fill: parent
            color: "#78e6eaed"
            border.color: "#c8ffffff"
            border.width: 1
        }
    }

    function toggleLiveTile() {
        const tile = tileStore.tiles[root.tileIndex]
        if (!tileStore.updateTile(root.tileIndex, { liveEnabled: !tile.liveEnabled }))
            return
        root.close()
    }

    function toggleCustomContent() {
        const tile = tileStore.tiles[root.tileIndex]
        if (tile.customContentMode !== "none") {
            if (tileStore.updateTile(root.tileIndex, {
                customContentMode: "none",
                customContentSource: ""
            }))
                root.close()
            return
        }
        root.close()
        root.chooseCustomContent()
    }

    Column {
        id: menuColumn
        width: root.width - root.padding * 2
        spacing: 3
        transform: Scale {
            id: unfoldScale
            origin.x: menuColumn.width / 2
            origin.y: 0
            yScale: 1
        }

        Label {
            width: parent.width
            leftPadding: 14
            topPadding: 7
            bottomPadding: 7
            text: root.tileIndex >= 0 ? tileStore.tiles[root.tileIndex].title : ""
            color: "#343a40"
            font.pixelSize: 12
            elide: Text.ElideRight
        }

        Rectangle {
            width: parent.width
            height: 1
            color: "#606b7379"
        }

        MetroButton {
            id: liveToggle
            width: parent.width
            height: 52
            restingColor: "#47ffffff"
            pressedColor: "#171a1d"
            disabledColor: "#c6c6c6"
            enabled: root.tileIndex >= 0

            contentItem: RowLayout {
                spacing: 13
                Rectangle {
                    width: 20
                    height: 20
                    radius: 0
                    color: root.tileIndex >= 0 && tileStore.tiles[root.tileIndex].liveEnabled
                           ? "#171a1d" : "transparent"
                    border.color: liveToggle.down || (root.tileIndex >= 0
                                       && tileStore.tiles[root.tileIndex].liveEnabled)
                                  ? "white" : "#282d31"
                    border.width: 2
                    Text {
                        anchors.centerIn: parent
                        text: root.tileIndex >= 0 && tileStore.tiles[root.tileIndex].liveEnabled
                              ? "✓" : ""
                        color: liveToggle.down || (root.tileIndex >= 0
                               && tileStore.tiles[root.tileIndex].liveEnabled)
                               ? "white" : "#202428"
                        font.pixelSize: 15
                    }
                }
                Label {
                    Layout.fillWidth: true
                    text: "动态磁贴"
                    color: liveToggle.down ? "white" : "#171a1d"
                    font.pixelSize: 17
                }
            }
            onClicked: root.toggleLiveTile()
        }

        MetroButton {
            id: customContentToggle
            width: parent.width
            height: 52
            restingColor: "#47ffffff"
            pressedColor: "#171a1d"
            disabledColor: "#c6c6c6"
            enabled: root.tileIndex >= 0

            contentItem: RowLayout {
                spacing: 13
                Rectangle {
                    width: 20
                    height: 20
                    radius: 0
                    color: root.tileIndex >= 0
                           && tileStore.tiles[root.tileIndex].customContentMode !== "none"
                           ? "#171a1d" : "transparent"
                    border.color: customContentToggle.down || (root.tileIndex >= 0
                                       && tileStore.tiles[root.tileIndex].customContentMode !== "none")
                                  ? "white" : "#282d31"
                    border.width: 2
                    Text {
                        anchors.centerIn: parent
                        text: root.tileIndex >= 0
                              && tileStore.tiles[root.tileIndex].customContentMode !== "none"
                              ? "✓" : ""
                        color: customContentToggle.down || (root.tileIndex >= 0
                               && tileStore.tiles[root.tileIndex].customContentMode !== "none")
                               ? "white" : "#202428"
                        font.pixelSize: 15
                    }
                }
                Label {
                    Layout.fillWidth: true
                    text: "自定义动态内容"
                    color: customContentToggle.down ? "white" : "#171a1d"
                    font.pixelSize: 17
                }
            }
            onClicked: root.toggleCustomContent()
        }

        MetroButton {
            id: customize
            width: parent.width
            height: 52
            restingColor: "#47ffffff"
            pressedColor: "#171a1d"
            contentItem: RowLayout {
                Label {
                    Layout.fillWidth: true
                    leftPadding: 34
                    text: "自定义磁贴"
                    color: customize.down ? "white" : "#171a1d"
                    font.pixelSize: 17
                }
                Label {
                    text: "›"
                    color: customize.down ? "white" : "#202428"
                    font.pixelSize: 28
                    Layout.rightMargin: 12
                }
            }
            onClicked: {
                root.close()
                root.editAppearance()
            }
        }

        Rectangle {
            width: parent.width
            height: 1
            color: "#606b7379"
        }

        MetroButton {
            id: resetTile
            width: parent.width
            height: 48
            text: "恢复默认磁贴"
            restingColor: "#47ffffff"
            pressedColor: "#171a1d"
            onClicked: {
                tileStore.resetTile(root.tileIndex)
                root.close()
            }
        }
    }

    ParallelAnimation {
        id: menuReveal
        NumberAnimation {
            target: unfoldScale
            property: "yScale"
            from: 0.12
            to: 1
            duration: 210
            easing.type: Easing.OutCubic
        }
        NumberAnimation {
            target: menuColumn
            property: "opacity"
            from: 0
            to: 1
            duration: 170
        }
    }
}
