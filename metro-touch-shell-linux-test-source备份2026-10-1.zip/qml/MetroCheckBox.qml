import QtQuick
import QtQuick.Controls

CheckBox {
    id: control

    property color textColor: "white"
    implicitHeight: 34
    spacing: 9

    indicator: Rectangle {
        implicitWidth: 21
        implicitHeight: 21
        x: control.leftPadding
        y: control.height / 2 - height / 2
        color: control.checked ? "#171a1d" : "transparent"
        border.color: control.enabled ? "#f2ffffff" : "#909090"
        border.width: 2
        radius: 0

        Text {
            anchors.centerIn: parent
            text: control.checked ? "✓" : ""
            color: "white"
            font.pixelSize: 15
        }
    }

    contentItem: Text {
        text: control.text
        color: control.enabled ? control.textColor : "#999999"
        font: control.font
        verticalAlignment: Text.AlignVCenter
        leftPadding: control.indicator.width + control.spacing
        elide: Text.ElideRight
    }
}
