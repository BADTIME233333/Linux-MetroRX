import QtQuick
import QtQuick.Controls

Slider {
    id: control

    implicitHeight: 34

    background: Rectangle {
        x: control.leftPadding
        y: control.topPadding + (control.availableHeight - height) / 2
        width: control.availableWidth
        height: 7
        color: "#687d8991"

        Rectangle {
            width: control.visualPosition * parent.width
            height: parent.height
            color: "#f5ffffff"
        }
    }

    handle: Rectangle {
        x: control.leftPadding + control.visualPosition
           * (control.availableWidth - width)
        y: control.topPadding + (control.availableHeight - height) / 2
        width: 18
        height: 28
        color: control.pressed ? "#171a1d" : "#f5f5f5"
        border.color: control.pressed ? "#555555" : "#9da3a7"
        border.width: 1
        radius: 0
    }
}
