import QtQuick

Canvas {
    id: root

    required property var layerData
    required property real cornerRadius
    required property real tileOpacity

    onLayerDataChanged: requestPaint()
    onCornerRadiusChanged: requestPaint()
    onTileOpacityChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        const context = getContext("2d")
        context.clearRect(0, 0, width, height)

        const first = Qt.color(layerData.color)
        const second = Qt.color(layerData.type === "gradient"
                                ? layerData.endColor : layerData.color)
        const firstColor = Qt.hsva(Math.max(0, first.hsvHue),
                                   Math.max(0, first.hsvSaturation * layerData.saturation),
                                   Math.max(0, first.hsvValue * layerData.brightness),
                                   1)
        const secondColor = Qt.hsva(Math.max(0, second.hsvHue),
                                    Math.max(0, second.hsvSaturation * layerData.saturation),
                                    Math.max(0, second.hsvValue * layerData.brightness),
                                    1)

        context.globalAlpha = layerData.opacity * tileOpacity
        if (layerData.type === "gradient") {
            const angle = layerData.angle * Math.PI / 180
            const dx = Math.cos(angle) * width / 2
            const dy = Math.sin(angle) * height / 2
            const gradient = context.createLinearGradient(width / 2 - dx, height / 2 - dy,
                                                          width / 2 + dx, height / 2 + dy)
            gradient.addColorStop(0, firstColor)
            gradient.addColorStop(1, secondColor)
            context.fillStyle = gradient
        } else {
            context.fillStyle = firstColor
        }

        const radius = Math.max(0, Math.min(cornerRadius, width / 2, height / 2))
        context.beginPath()
        context.moveTo(radius, 0)
        context.lineTo(width - radius, 0)
        context.quadraticCurveTo(width, 0, width, radius)
        context.lineTo(width, height - radius)
        context.quadraticCurveTo(width, height, width - radius, height)
        context.lineTo(radius, height)
        context.quadraticCurveTo(0, height, 0, height - radius)
        context.lineTo(0, radius)
        context.quadraticCurveTo(0, 0, radius, 0)
        context.closePath()
        context.fill()
    }
}
