import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts

Popup {
    id: root

    required property int tileIndex
    property int selectedLayerIndex: 0
    property bool editingEndColor: false
    property var tileData: tileIndex >= 0 ? tileStore.tiles[tileIndex] : ({})
    property color activeColor: "#1680a0"
    property real activeHue: 0.55

    parent: Overlay.overlay
    width: Math.min(parent.width - 28, 1020)
    height: Math.min(parent.height - 28, 720)
    x: Math.max(14, parent.width - width - 14)
    y: Math.max(14, (parent.height - height) / 2)
    padding: 18
    modal: true
    focus: true
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

    background: Rectangle {
        radius: 4
        color: "#f0132737"
        border.color: "#65ffffff"
        border.width: 1
    }

    function selectedLayer() {
        if (root.tileIndex < 0)
            return ({})
        const layers = tileStore.tiles[root.tileIndex].layers
        if (root.selectedLayerIndex < 0 || root.selectedLayerIndex >= layers.length)
            return ({})
        return layers[root.selectedLayerIndex]
    }

    function loadSelectedLayer() {
        const layer = root.selectedLayer()
        if (Object.keys(layer).length === 0)
            return
        root.editingEndColor = false
        root.activeColor = layer.color
        const color = Qt.color(layer.color)
        root.activeHue = color.hsvHue >= 0 ? color.hsvHue : 0
        saturationSlider.value = color.hsvSaturation
        brightnessSlider.value = color.hsvValue
        activeOpacitySlider.value = layer.opacity
        layerAngleSlider.value = layer.angle
        adaptiveColorCheck.checked = layer.autoColor
    }

    function selectGradientColor(endColor) {
        const layer = root.selectedLayer()
        root.editingEndColor = endColor
        const color = Qt.color(endColor ? layer.endColor : layer.color)
        root.activeColor = color
        root.activeHue = color.hsvHue >= 0 ? color.hsvHue : 0
        saturationSlider.value = color.hsvSaturation
        brightnessSlider.value = color.hsvValue
    }

    function applyColor(hue, saturation, brightness) {
        const color = Qt.hsva(hue, saturation, brightness, 1).toString()
        const key = root.editingEndColor && root.selectedLayer().type === "gradient"
                    ? "endColor" : "color"
        const changes = {}
        changes[key] = color
        if (!tileStore.updateLayer(root.tileIndex, root.selectedLayerIndex, changes))
            return
        root.activeColor = color
    }

    function updateLayer(changes) {
        tileStore.updateLayer(root.tileIndex, root.selectedLayerIndex, changes)
    }

    onOpened: {
        selectedLayerIndex = Math.max(0, tileData.layers.length - 1)
        tileOpacitySlider.value = tileData.opacity
        loadSelectedLayer()
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 12

        RowLayout {
            Layout.fillWidth: true

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Label {
                    text: "自定义磁贴"
                    color: "white"
                    font.pixelSize: 23
                    font.weight: Font.Light
                }
                Label {
                    text: root.tileIndex >= 0 ? root.tileData.title + " · 设置自动保存" : ""
                    color: "#bdffffff"
                    font.pixelSize: 12
                }
            }

            MetroButton {
                text: root.tileData.iconSource && root.tileData.iconSource.length > 0
                      ? "更换图标" : "选择图标"
                onClicked: iconPicker.open()
                restingColor: "#203745"
                pressedColor: "#171a1d"
                restingTextColor: "white"
            }

            MetroButton {
                width: 42
                height: 42
                implicitHeight: 42
                text: "×"
                font.pixelSize: 24
                restingColor: "#203745"
                pressedColor: "#171a1d"
                restingTextColor: "white"
                onClicked: root.close()
                Accessible.name: "关闭磁贴自定义"
            }
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: "#42ffffff"
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 18

            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.preferredWidth: 650
                spacing: 12

                RowLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    spacing: 20

                    Item {
                        Layout.preferredWidth: Math.min(190, parent.height - 32)
                        Layout.preferredHeight: Layout.preferredWidth

                        Canvas {
                            id: hueWheel
                            anchors.fill: parent

                            onPaint: {
                                const context = getContext("2d")
                                context.clearRect(0, 0, width, height)
                                const centerX = width / 2
                                const centerY = height / 2
                                const radius = Math.min(width, height) * 0.47
                                const segments = 120
                                for (let i = 0; i < segments; ++i) {
                                    const start = i * 2 * Math.PI / segments
                                    const end = (i + 1) * 2 * Math.PI / segments
                                    context.beginPath()
                                    context.moveTo(centerX, centerY)
                                    context.arc(centerX, centerY, radius, start, end)
                                    context.closePath()
                                    context.fillStyle = Qt.hsva(i / segments, 1, 1, 1).toString()
                                    context.fill()
                                }
                            }

                            onWidthChanged: requestPaint()
                            onHeightChanged: requestPaint()

                            TapHandler {
                                onTapped: {
                                    const centerX = hueWheel.width / 2
                                    const centerY = hueWheel.height / 2
                                    const dx = point.position.x - centerX
                                    const dy = point.position.y - centerY
                                    if (Math.hypot(dx, dy) > Math.min(centerX, centerY))
                                        return
                                    root.activeHue = (Math.atan2(dy, dx) / (2 * Math.PI) + 1) % 1
                                    root.applyColor(root.activeHue,
                                                    saturationSlider.value,
                                                    brightnessSlider.value)
                                }
                            }

                            Rectangle {
                                width: 18
                                height: 18
                                radius: 9
                                color: "white"
                                border.color: "#a0000000"
                                border.width: 2
                                x: hueWheel.width / 2
                                   + Math.cos(root.activeHue * 2 * Math.PI) * hueWheel.width * 0.38
                                   - width / 2
                                y: hueWheel.height / 2
                                   + Math.sin(root.activeHue * 2 * Math.PI) * hueWheel.height * 0.38
                                   - height / 2
                            }
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 8

                        Label {
                            text: root.editingEndColor && root.selectedLayer().type === "gradient"
                                  ? "渐变终点颜色" : "图层颜色"
                            color: "white"
                            font.pixelSize: 15
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            visible: root.selectedLayer().type === "gradient"
                            MetroButton {
                                Layout.fillWidth: true
                                text: "起点"
                                highlighted: !root.editingEndColor
                                restingColor: "#203745"
                                pressedColor: "#171a1d"
                                restingTextColor: "white"
                                onClicked: root.selectGradientColor(false)
                            }
                            MetroButton {
                                Layout.fillWidth: true
                                text: "终点"
                                highlighted: root.editingEndColor
                                restingColor: "#203745"
                                pressedColor: "#171a1d"
                                restingTextColor: "white"
                                onClicked: root.selectGradientColor(true)
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 38
                            radius: 3
                            color: root.activeColor
                            border.color: "#55ffffff"
                            border.width: 1
                        }

                        Label {
                            text: "饱和度  " + Math.round(saturationSlider.value * 100) + "%"
                            color: "#e3ffffff"
                            font.pixelSize: 12
                        }
                        MetroSlider {
                            id: saturationSlider
                            Layout.fillWidth: true
                            from: 0
                            to: 1
                            stepSize: 0.01
                            onMoved: root.applyColor(root.activeHue, value, brightnessSlider.value)
                        }

                        Label {
                            text: "明度  " + Math.round(brightnessSlider.value * 100) + "%"
                            color: "#e3ffffff"
                            font.pixelSize: 12
                        }
                        MetroSlider {
                            id: brightnessSlider
                            Layout.fillWidth: true
                            from: 0
                            to: 1
                            stepSize: 0.01
                            onMoved: root.applyColor(root.activeHue, saturationSlider.value, value)
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Label {
                                Layout.fillWidth: true
                                text: "当前颜色"
                                color: "#c8ffffff"
                            }
                            TextField {
                                id: hexColorField
                                Layout.preferredWidth: 116
                                text: root.activeColor.toString()
                                validator: RegularExpressionValidator {
                                    regularExpression: /^#[0-9A-Fa-f]{6}$/
                                }
                                onEditingFinished: {
                                    const color = Qt.color(text)
                                    if (!color.valid)
                                        return
                                    const changes = {}
                                    changes[root.editingEndColor
                                            && root.selectedLayer().type === "gradient"
                                            ? "endColor" : "color"] = color.toString()
                                    root.updateLayer(changes)
                                    root.activeColor = color
                                    root.activeHue = Math.max(0, color.hsvHue)
                                    saturationSlider.value = color.hsvSaturation
                                    brightnessSlider.value = color.hsvValue
                                }
                            }
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        text: "透明度  " + Math.round(tileOpacitySlider.value * 100) + "%"
                        color: "white"
                    }
                    MetroSlider {
                        id: tileOpacitySlider
                        Layout.preferredWidth: 205
                        Layout.maximumWidth: 220
                        from: 0.15
                        to: 1
                        stepSize: 0.01
                        onMoved: tileStore.updateTile(root.tileIndex, { opacity: value })
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        text: "图层透明度  " + Math.round(activeOpacitySlider.value * 100) + "%"
                        color: "white"
                    }
                    MetroSlider {
                        id: activeOpacitySlider
                        Layout.preferredWidth: 205
                        Layout.maximumWidth: 220
                        from: 0
                        to: 1
                        stepSize: 0.01
                        onMoved: root.updateLayer({ opacity: value })
                    }
                }

                MetroCheckBox {
                    visible: root.tileData.customContentMode === "video"
                    text: "视频循环播放"
                    checked: root.tileData.videoLoop
                    onClicked: tileStore.updateTile(root.tileIndex, { videoLoop: checked })
                }

                Label { text: "阴影样式"; color: "white" }

                GridLayout {
                    columns: 2
                    Layout.fillWidth: true
                    rowSpacing: 6
                    columnSpacing: 6

                    MetroButton {
                        Layout.fillWidth: true
                        text: "无阴影"
                        highlighted: root.tileData.shadowMode === "none"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        pressedTextColor: "white"
                        onClicked: tileStore.updateTile(root.tileIndex, { shadowMode: "none" })
                    }

                    MetroButton {
                        Layout.fillWidth: true
                        text: "外阴影"
                        highlighted: root.tileData.shadowMode === "outer"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        pressedTextColor: "white"
                        onClicked: tileStore.updateTile(root.tileIndex, { shadowMode: "outer" })
                    }

                    MetroButton {
                        Layout.fillWidth: true
                        text: "内阴影"
                        highlighted: root.tileData.shadowMode === "inset"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        pressedTextColor: "white"
                        onClicked: tileStore.updateTile(root.tileIndex, { shadowMode: "inset" })
                    }

                    MetroButton {
                        Layout.fillWidth: true
                        text: "内外叠加"
                        highlighted: root.tileData.shadowMode === "both"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        pressedTextColor: "white"
                        onClicked: tileStore.updateTile(root.tileIndex, { shadowMode: "both" })
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Label { text: "曲率"; color: "white" }
                    Repeater {
                        model: [
                            { key: "square", label: "方角" },
                            { key: "micro", label: "微曲" },
                            { key: "natural", label: "自然曲" },
                            { key: "medium", label: "中曲" },
                            { key: "high", label: "高曲" },
                            { key: "circle", label: "圆形" }
                        ]

                        delegate: MetroButton {
                            required property var modelData
                            text: modelData.label
                            highlighted: root.tileData.cornerPreset === modelData.key
                            restingColor: "#203745"
                            pressedColor: "#171a1d"
                            restingTextColor: "white"
                            onClicked: tileStore.updateTile(root.tileIndex, {
                                cornerPreset: modelData.key
                            })
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    MetroCheckBox {
                        id: adaptiveColorCheck
                        text: "自动适配图标边缘颜色"
                        checked: false
                        enabled: root.tileData.iconSource && root.tileData.iconSource.length > 0
                        onClicked: root.updateLayer({ autoColor: checked })
                    }

                    Label {
                        Layout.fillWidth: true
                        text: "需提供图标图片；暂未提供时保留当前选色。"
                        color: "#aaffffff"
                        font.pixelSize: 11
                        elide: Text.ElideRight
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        Layout.fillWidth: true
                        text: "渐变角度  " + Math.round(layerAngleSlider.value) + "°"
                        color: "#d7ffffff"
                        enabled: root.selectedLayer().type === "gradient"
                    }
                    MetroSlider {
                        id: layerAngleSlider
                        Layout.fillWidth: true
                        from: 0
                        to: 359
                        stepSize: 1
                        enabled: root.selectedLayer().type === "gradient"
                        onMoved: root.updateLayer({ angle: Math.round(value) })
                    }
                }
            }

            Rectangle {
                Layout.fillHeight: true
                width: 1
                color: "#3cffffff"
            }

            ColumnLayout {
                Layout.preferredWidth: 238
                Layout.fillHeight: true
                spacing: 9

                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        Layout.fillWidth: true
                        text: "背景图层"
                        color: "white"
                        font.pixelSize: 17
                    }

                    MetroButton {
                        id: addLayerButton
                        text: "+  添加图层"
                        Layout.preferredWidth: 126
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        Accessible.name: "添加背景颜色图层"
                        onClicked: {
                            const position = addLayerButton.mapToItem(Overlay.overlay, 0, 0)
                            addLayerMenu.requestedX = position.x
                            addLayerMenu.requestedY = position.y - addLayerMenu.height - 8
                            addLayerMenu.open()
                        }
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: "最上层显示在列表上方；按住左侧把手可拖动排序。"
                    color: "#bbffffff"
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    MetroButton {
                        Layout.fillWidth: true
                        text: root.tileData.imageSource && root.tileData.imageSource.length > 0
                              ? "更换背景图片" : "选择背景图片"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        onClicked: backgroundPicker.open()
                    }
                    MetroButton {
                        text: "移除"
                        enabled: root.tileData.imageSource && root.tileData.imageSource.length > 0
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        onClicked: tileStore.updateTile(root.tileIndex, { imageSource: "" })
                        Accessible.name: "移除磁贴背景图片"
                    }
                }

                ListView {
                    id: layerList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    model: root.tileIndex >= 0 ? root.tileData.layers.length : 0
                    spacing: 6
                    clip: true
                    boundsBehavior: Flickable.StopAtBounds

                    delegate: Rectangle {
                        id: layerRow
                        required property int index
                        property int layerIndex: root.tileData.layers.length - 1 - index
                        property var modelData: root.tileData.layers[layerIndex]
                        width: layerList.width
                        height: 50
                        radius: 3
                        color: root.selectedLayerIndex === layerIndex ? "#44ffffff" : "#19ffffff"
                        border.color: root.selectedLayerIndex === layerIndex ? "#b0ffffff" : "#32ffffff"
                        border.width: 1

                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 7
                            anchors.rightMargin: 5
                            spacing: 5

                            Text {
                                id: dragHandle
                                text: "⠿"
                                color: "#ddffffff"
                                font.pixelSize: 19

                                DragHandler {
                                    id: layerDrag
                                    target: null
                                    onActiveChanged: {
                                        if (!active)
                                            return
                                        root.selectedLayerIndex = layerRow.layerIndex
                                    }
                                    onCentroidChanged: {
                                        if (!active)
                                            return
                                        const position = layerList.contentItem.mapFromItem(
                                                    null,
                                                    centroid.scenePosition.x,
                                                    centroid.scenePosition.y)
                                        const targetRow = layerList.indexAt(position.x, position.y)
                                        const targetIndex = root.tileData.layers.length - 1 - targetRow
                                        if (targetRow >= 0 && targetIndex !== root.selectedLayerIndex) {
                                            if (tileStore.moveLayer(root.tileIndex,
                                                                    root.selectedLayerIndex,
                                                                    targetIndex))
                                                root.selectedLayerIndex = targetIndex
                                        }
                                    }
                                }
                            }

                            Rectangle {
                                width: 27
                                height: 27
                                radius: 2
                                color: layerRow.modelData.color
                                border.color: "#75ffffff"
                                border.width: 1
                            }

                            MetroButton {
                                Layout.fillWidth: true
                                flat: true
                                text: layerRow.modelData.type === "gradient" ? "渐变" : "单色"
                                restingColor: "#203745"
                                pressedColor: "#171a1d"
                                restingTextColor: "white"
                                onClicked: {
                                    root.selectedLayerIndex = layerRow.layerIndex
                                    root.loadSelectedLayer()
                                }
                            }

                            MetroButton {
                                width: 38
                                height: 38
                                implicitHeight: 38
                                restingColor: "#203745"
                                pressedColor: "#171a1d"
                                restingTextColor: "white"
                                text: "×"
                                font.pixelSize: 19
                                enabled: root.tileData.layers.length > 1
                                onClicked: {
                                    tileStore.removeLayer(root.tileIndex, layerRow.layerIndex)
                                    root.selectedLayerIndex = Math.max(
                                                0, Math.min(root.selectedLayerIndex,
                                                            root.tileData.layers.length - 2))
                                    root.loadSelectedLayer()
                                }
                                Accessible.name: "删除图层"
                            }
                        }

                        TapHandler {
                            onTapped: {
                                root.selectedLayerIndex = layerRow.layerIndex
                                root.loadSelectedLayer()
                            }
                        }
                    }
                }

                Popup {
                    id: addLayerMenu
                    property real requestedX: 0
                    property real requestedY: 0

                    parent: Overlay.overlay
                    width: 154
                    height: layerTypeOptions.implicitHeight + 10
                    padding: 5
                    x: Math.max(8, Math.min(parent.width - width - 8, requestedX))
                    y: Math.max(8, Math.min(parent.height - height - 8, requestedY))
                    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
                    onOpened: {
                        layerTypeScale.yScale = 0.12
                        layerTypeReveal.restart()
                    }

                    background: Rectangle {
                        color: "#e6edf0f2"
                        border.color: "#bbffffff"
                        border.width: 1
                    }

                    Column {
                        id: layerTypeOptions
                        width: addLayerMenu.width - addLayerMenu.padding * 2
                        spacing: 3
                        transform: Scale {
                            id: layerTypeScale
                            origin.x: layerTypeOptions.width / 2
                            origin.y: 0
                            yScale: 1
                        }

                        MetroButton {
                            width: parent.width
                            text: "单色"
                            onClicked: {
                                if (tileStore.addLayer(root.tileIndex, "solid")) {
                                    root.selectedLayerIndex = root.tileData.layers.length - 1
                                    root.loadSelectedLayer()
                                }
                                addLayerMenu.close()
                            }
                        }

                        MetroButton {
                            width: parent.width
                            text: "渐变"
                            onClicked: {
                                if (tileStore.addLayer(root.tileIndex, "gradient")) {
                                    root.selectedLayerIndex = root.tileData.layers.length - 1
                                    root.loadSelectedLayer()
                                    root.selectGradientColor(true)
                                }
                                addLayerMenu.close()
                            }
                        }
                    }

                    ParallelAnimation {
                        id: layerTypeReveal
                        NumberAnimation {
                            target: layerTypeScale
                            property: "yScale"
                            from: 0.12
                            to: 1
                            duration: 190
                            easing.type: Easing.OutCubic
                        }
                        NumberAnimation {
                            target: layerTypeOptions
                            property: "opacity"
                            from: 0
                            to: 1
                            duration: 160
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Item { Layout.fillWidth: true }
                    MetroButton {
                        text: "恢复默认磁贴"
                        restingColor: "#203745"
                        pressedColor: "#171a1d"
                        restingTextColor: "white"
                        onClicked: {
                            tileStore.resetTile(root.tileIndex)
                            root.close()
                        }
                    }
                    MetroButton {
                        text: "完成"
                        highlighted: true
                        restingColor: "#e9edf0"
                        pressedColor: "#171a1d"
                        restingTextColor: "#151515"
                        pressedTextColor: "white"
                        onClicked: root.close()
                    }
                }
            }
        }

        FileDialog {
            id: iconPicker
            title: "选择应用图标图片"
            nameFilters: ["图片文件 (*.png *.jpg *.jpeg *.webp *.bmp)", "所有文件 (*)"]
            fileMode: FileDialog.OpenFile
            onAccepted: tileStore.updateTile(root.tileIndex, {
                iconSource: selectedFile.toString()
            })
        }

        FileDialog {
            id: backgroundPicker
            title: "选择磁贴背景图片"
            nameFilters: ["图片文件 (*.png *.jpg *.jpeg *.webp *.bmp *.gif)", "所有文件 (*)"]
            fileMode: FileDialog.OpenFile
            onAccepted: tileStore.updateTile(root.tileIndex, {
                imageSource: selectedFile.toString()
            })
        }
    }
}
