#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build_dir="${BUILD_DIR:-$project_root/build-linux-test}"
output_dir="${OUTPUT_DIR:-$project_root/dist}"
architecture="$(uname -m)"

for command in cmake c++ tar; do
    if ! command -v "$command" >/dev/null 2>&1; then
        printf 'Missing required build tool: %s\n' "$command" >&2
        exit 1
    fi
done

mkdir -p "$output_dir"
stage="$(mktemp -d "${TMPDIR:-/tmp}/metro-touch-shell.XXXXXX")"
trap 'rm -rf -- "$stage"' EXIT

cmake -S "$project_root" -B "$build_dir" \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=/usr
cmake --build "$build_dir" --parallel

package_name="metro-touch-shell-linux-$architecture"
package_root="$stage/$package_name"
mkdir -p "$package_root"
DESTDIR="$package_root" cmake --install "$build_dir"

cat > "$package_root/run.sh" <<'EOF'
#!/usr/bin/env sh
set -eu
package_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec "$package_root/usr/bin/metro-touch-shell" "$@"
EOF
chmod +x "$package_root/run.sh"

cat > "$package_root/README.txt" <<'EOF'
Metro Touch Shell - Linux test build

Run ./run.sh from this directory. This is a regular Qt Quick application
window; it does not replace KDE or change login/session settings.

The target system needs Qt 6.5 or newer, including Qt Quick, Qt Quick
Controls, Qt Quick Dialogs, Qt Quick Effects, and Qt Multimedia runtime modules. Install
matching Qt runtime packages if the application reports a missing Qt module
or shared library. Video playback also depends on the codecs supported by
the target system's Qt Multimedia backend.

This archive contains the application executable, not a bundled copy of Qt.
Build the archive on Linux with packaging/build-linux-test.sh.
EOF

archive="$output_dir/$package_name.tar.gz"
tar -C "$stage" -czf "$archive" "$package_name"
printf 'Created Linux test package: %s\n' "$archive"
