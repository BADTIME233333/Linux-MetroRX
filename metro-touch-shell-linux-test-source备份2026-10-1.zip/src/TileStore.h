#pragma once

#include <QAbstractListModel>
#include <QHash>
#include <QModelIndex>
#include <QObject>
#include <QSettings>
#include <QString>
#include <QTimer>
#include <QVariantList>
#include <QVariantMap>

class TileListModel final : public QAbstractListModel
{
    Q_OBJECT

public:
    enum Role {
        TileRole = Qt::UserRole + 1,
    };

    explicit TileListModel(QObject *parent = nullptr);
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    void setTiles(const QVariantList &tiles);
    void updateTile(int index, const QVariantMap &tile);

private:
    QVariantList m_tiles;
};

class TileStore final : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariantList tiles READ tiles NOTIFY tilesChanged)
    Q_PROPERTY(QAbstractItemModel *tileModel READ tileModel CONSTANT)

public:
    explicit TileStore(QObject *parent = nullptr);

    QVariantList tiles() const;
    QAbstractItemModel *tileModel();

    Q_INVOKABLE bool updateTile(int index, const QVariantMap &changes);
    Q_INVOKABLE bool addLayer(int tileIndex, const QString &type);
    Q_INVOKABLE bool updateLayer(int tileIndex, int layerIndex, const QVariantMap &changes);
    Q_INVOKABLE bool removeLayer(int tileIndex, int layerIndex);
    Q_INVOKABLE bool moveLayer(int tileIndex, int fromIndex, int toIndex);
    Q_INVOKABLE bool beginTileEdit(int tileIndex);
    Q_INVOKABLE bool previewTilePlacement(int tileIndex,
                                          int page,
                                          int column,
                                          int row,
                                          int columns,
                                          int rows);
    Q_INVOKABLE bool finishTileEdit();
    Q_INVOKABLE void cancelTileEdit();
    Q_INVOKABLE void resetTile(int index);

signals:
    void tilesChanged();
    void operationFailed(const QString &message);

private:
    static QVariantList defaultTiles();
    bool layoutIsValid(int editedIndex, const QVariantMap &candidate) const;
    bool arrangeCollisions(QVariantList *tiles, int fixedIndex, int vacancyColumn, int vacancyRow) const;
    void publishTiles(const QVariantList &tiles);
    bool commitTile(int index, const QVariantMap &updated);
    bool save();

    QVariantList m_tiles;
    TileListModel m_tileModel;
    QSettings m_settings;
    QTimer m_saveTimer;
    QVariantList m_editSnapshot;
    int m_editIndex = -1;
    bool m_editChanged = false;
};
