#include "TileStore.h"

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("LinuxProjectDesk"));
    QCoreApplication::setApplicationName(QStringLiteral("MetroTouchShell"));

    TileStore tileStore;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("tileStore"), &tileStore);
    engine.loadFromModule(QStringLiteral("MetroTouchShell"), QStringLiteral("Main"));

    if (engine.rootObjects().isEmpty()) {
        return 1;
    }

    return app.exec();
}
