#include "TileStore.h"

#include <QColor>
#include <QImage>
#include <QImageReader>
#include <QSettings>
#include <QStringList>
#include <QtMath>
#include <QUrl>

#include <algorithm>
#include <optional>
#include <tuple>
#include <vector>

namespace
{
constexpr int GridColumns = 10;
constexpr int GridRows = 10;
constexpr int LegacyGridColumns = 6;
constexpr int LegacyGridRows = 3;

int scaleGridPosition(int position, int oldGridSize, int newGridSize)
{
    return qRound(static_cast<double>(position) * newGridSize / oldGridSize);
}

int scaleGridSpan(int position, int span, int oldGridSize, int newGridSize)
{
    return scaleGridPosition(position + span, oldGridSize, newGridSize)
        - scaleGridPosition(position, oldGridSize, newGridSize);
}

QVariantMap tile(const QString &title,
                 const QString &subtitle,
                 const QString &icon,
                 const QString &color,
                 int page,
                 int column,
                 int row,
                 int columns,
                 int rows,
                 const QStringList &liveItems = {},
                 const QString &cornerPreset = QStringLiteral("square"))
{
    const int gridColumn = scaleGridPosition(column, LegacyGridColumns, GridColumns);
    const int gridRow = scaleGridPosition(row, LegacyGridRows, GridRows);
    const int gridColumns = scaleGridSpan(column, columns, LegacyGridColumns, GridColumns);
    const int gridRows = scaleGridSpan(row, rows, LegacyGridRows, GridRows);
    const QVariantMap initialLayer{
        {QStringLiteral("type"), QStringLiteral("solid")},
        {QStringLiteral("color"), color},
        {QStringLiteral("endColor"), color},
        {QStringLiteral("angle"), 0},
        {QStringLiteral("opacity"), 1.0},
        {QStringLiteral("saturation"), 1.0},
        {QStringLiteral("brightness"), 1.0},
        {QStringLiteral("autoColor"), true},
    };
    return {
        {QStringLiteral("title"), title},
        {QStringLiteral("subtitle"), subtitle},
        {QStringLiteral("icon"), icon},
        {QStringLiteral("iconSource"), QString()},
        {QStringLiteral("color"), color},
        {QStringLiteral("gradientEnd"), color},
        {QStringLiteral("gradientEnabled"), false},
        {QStringLiteral("imageSource"), QString()},
        {QStringLiteral("opacity"), 1.0},
        {QStringLiteral("radius"), 0},
        {QStringLiteral("shadowMode"), QStringLiteral("outer")},
        {QStringLiteral("page"), page},
        {QStringLiteral("column"), gridColumn},
        {QStringLiteral("row"), gridRow},
        {QStringLiteral("columns"), gridColumns},
        {QStringLiteral("rows"), gridRows},
        {QStringLiteral("liveEnabled"), !liveItems.isEmpty()},
        {QStringLiteral("liveItems"), liveItems},
        {QStringLiteral("customContentMode"), QStringLiteral("none")},
        {QStringLiteral("customContentSource"), QString()},
        {QStringLiteral("videoLoop"), true},
        {QStringLiteral("cornerPreset"), cornerPreset},
        {QStringLiteral("layers"), QVariantList{initialLayer}},
    };
}

bool intersects(const QVariantMap &left, const QVariantMap &right)
{
    if (left.value(QStringLiteral("page")).toInt() != right.value(QStringLiteral("page")).toInt()) {
        return false;
    }

    const int leftColumn = left.value(QStringLiteral("column")).toInt();
    const int leftRow = left.value(QStringLiteral("row")).toInt();
    const int rightColumn = right.value(QStringLiteral("column")).toInt();
    const int rightRow = right.value(QStringLiteral("row")).toInt();

    return leftColumn < rightColumn + right.value(QStringLiteral("columns")).toInt()
        && rightColumn < leftColumn + left.value(QStringLiteral("columns")).toInt()
        && leftRow < rightRow + right.value(QStringLiteral("rows")).toInt()
        && rightRow < leftRow + left.value(QStringLiteral("rows")).toInt();
}

int gridDistance(const QVariantMap &tile, int column, int row)
{
    return qAbs(tile.value(QStringLiteral("column")).toInt() - column)
        + qAbs(tile.value(QStringLiteral("row")).toInt() - row);
}

QColor averageIconEdge(const QImage &image, bool topEdge)
{
    const int width = image.width();
    const int height = image.height();
    const int bandHeight = qMax(1, height / 5);
    quint64 red = 0;
    quint64 green = 0;
    quint64 blue = 0;
    quint64 samples = 0;

    for (int y = 0; y < height; y += qMax(1, height / 64)) {
        const bool inBand = topEdge ? y < bandHeight : y >= height - bandHeight;
        if (!inBand) {
            continue;
        }
        for (int x = 0; x < width; x += qMax(1, width / 128)) {
            const QColor color = image.pixelColor(x, y);
            red += color.red();
            green += color.green();
            blue += color.blue();
            ++samples;
        }
    }

    if (samples == 0) {
        return {};
    }
    return QColor(static_cast<int>(red / samples),
                  static_cast<int>(green / samples),
                  static_cast<int>(blue / samples));
}

bool applyIconEdgeColors(QVariantMap *layer, const QString &iconSource)
{
    const QUrl iconUrl(iconSource);
    const QString iconPath = iconUrl.isLocalFile() ? iconUrl.toLocalFile() : iconSource;
    QImageReader imageReader(iconPath);
    const QSize imageSize = imageReader.size();
    if (imageSize.isValid()) {
        imageReader.setScaledSize(imageSize.scaled(128, 128, Qt::KeepAspectRatio));
    }
    const QImage iconImage = imageReader.read();
    if (iconImage.isNull()) {
        return false;
    }

    const QColor startColor = averageIconEdge(iconImage, true);
    const QColor endColor = averageIconEdge(iconImage, false);
    if (!startColor.isValid() || !endColor.isValid()) {
        return false;
    }

    layer->insert(QStringLiteral("type"), QStringLiteral("gradient"));
    layer->insert(QStringLiteral("color"), startColor.name(QColor::HexRgb));
    layer->insert(QStringLiteral("endColor"), endColor.name(QColor::HexRgb));
    layer->insert(QStringLiteral("angle"), 90);
    layer->insert(QStringLiteral("autoColor"), true);
    return true;
}
}

TileListModel::TileListModel(QObject *parent)
    : QAbstractListModel(parent)
{
}

int TileListModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : m_tiles.size();
}

QVariant TileListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_tiles.size()
        || role != TileRole) {
        return {};
    }
    return m_tiles.at(index.row());
}

QHash<int, QByteArray> TileListModel::roleNames() const
{
    return {{TileRole, QByteArrayLiteral("tile")}};
}

void TileListModel::setTiles(const QVariantList &tiles)
{
    beginResetModel();
    m_tiles = tiles;
    endResetModel();
}

void TileListModel::updateTile(int index, const QVariantMap &tile)
{
    if (index < 0 || index >= m_tiles.size()) {
        return;
    }
    if (m_tiles.at(index) == tile) {
        return;
    }
    m_tiles[index] = tile;
    const QModelIndex changed = this->index(index, 0);
    emit dataChanged(changed, changed, {TileRole});
}

TileStore::TileStore(QObject *parent)
    : QObject(parent)
    , m_tiles(defaultTiles())
{
    const QVariantList savedTiles = m_settings.value(QStringLiteral("tiles")).toList();
    const bool migrateGrid = m_settings.value(QStringLiteral("tileLayoutVersion"), 1).toInt() < 2;
    if (savedTiles.size() == m_tiles.size()) {
        for (qsizetype index = 0; index < m_tiles.size(); ++index) {
            QVariantMap migrated = m_tiles.at(index).toMap();
            const QVariantMap saved = savedTiles.at(index).toMap();
            for (auto it = saved.cbegin(); it != saved.cend(); ++it) {
                migrated.insert(it.key(), it.value());
            }
            migrated.remove(QStringLiteral("shadowStrength"));
            if (migrated.value(QStringLiteral("shadowMode")).toString() == QStringLiteral("soft")) {
                migrated.insert(QStringLiteral("shadowMode"), QStringLiteral("outer"));
            }
            if (migrateGrid) {
                if (migrated.value(QStringLiteral("cornerPreset")).toString()
                    == QStringLiteral("micro")) {
                    migrated.insert(QStringLiteral("cornerPreset"), QStringLiteral("square"));
                }
                const int column = migrated.value(QStringLiteral("column")).toInt();
                const int row = migrated.value(QStringLiteral("row")).toInt();
                const int columns = migrated.value(QStringLiteral("columns")).toInt();
                const int rows = migrated.value(QStringLiteral("rows")).toInt();
                migrated.insert(QStringLiteral("column"),
                                scaleGridPosition(column, LegacyGridColumns, GridColumns));
                migrated.insert(QStringLiteral("row"),
                                scaleGridPosition(row, LegacyGridRows, GridRows));
                migrated.insert(QStringLiteral("columns"),
                                scaleGridSpan(column, columns, LegacyGridColumns, GridColumns));
                migrated.insert(QStringLiteral("rows"),
                                scaleGridSpan(row, rows, LegacyGridRows, GridRows));
            }
            m_tiles[index] = migrated;
        }
    }
    if (migrateGrid) {
        m_settings.setValue(QStringLiteral("tiles"), m_tiles);
        m_settings.sync();
        if (m_settings.status() != QSettings::NoError) {
            emit operationFailed(QStringLiteral("无法迁移旧版磁贴布局，请检查用户配置目录的权限。"));
        } else {
            m_settings.setValue(QStringLiteral("tileLayoutVersion"), 2);
            m_settings.sync();
            if (m_settings.status() != QSettings::NoError) {
                emit operationFailed(QStringLiteral("无法保存磁贴布局版本，请检查用户配置目录的权限。"));
            }
        }
    }
    m_tileModel.setTiles(m_tiles);

    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(220);
    connect(&m_saveTimer, &QTimer::timeout, this, [this] {
        m_settings.sync();
        if (m_settings.status() != QSettings::NoError) {
            emit operationFailed(QStringLiteral("磁贴设置没有保存成功，请检查用户配置目录的权限。"));
        }
    });
}

QVariantList TileStore::tiles() const
{
    return m_tiles;
}

QAbstractItemModel *TileStore::tileModel()
{
    return &m_tileModel;
}

QVariantList TileStore::defaultTiles()
{
    return {
        tile(QStringLiteral("照片"), QStringLiteral("最近的回忆"), QStringLiteral("▧"),
             QStringLiteral("#087da5"), 0, 0, 0, 2, 2,
             {QStringLiteral("周末漫步"), QStringLiteral("去年夏天")}),
        tile(QStringLiteral("天气"), QStringLiteral("18°  ·  多云"), QStringLiteral("☁"),
             QStringLiteral("#167b9b"), 0, 2, 0, 1, 1,
             {QStringLiteral("18°  ·  多云"), QStringLiteral("明天  20°")}),
        tile(QStringLiteral("日历"), QStringLiteral("10月 2日"), QStringLiteral("02"),
             QStringLiteral("#0078a8"), 0, 3, 0, 1, 1),
        tile(QStringLiteral("音乐"), QStringLiteral("正在播放"), QStringLiteral("♫"),
             QStringLiteral("#a52b76"), 0, 4, 0, 2, 1,
             {QStringLiteral("现在播放  ·  Playlist"), QStringLiteral("最近播放  ·  收藏")}),
        tile(QStringLiteral("邮件"), QStringLiteral("收件箱"), QStringLiteral("✉"),
             QStringLiteral("#1369a5"), 0, 2, 1, 1, 1),
        tile(QStringLiteral("照片墙"), QStringLiteral("旅行与日常"), QStringLiteral("▤"),
             QStringLiteral("#287d72"), 0, 3, 1, 1, 1),
        tile(QStringLiteral("浏览器"), QStringLiteral("打开网页"), QStringLiteral("◎"),
             QStringLiteral("#176fb0"), 0, 0, 2, 1, 1),
        tile(QStringLiteral("设置"), QStringLiteral("桌面与系统"), QStringLiteral("⚙"),
             QStringLiteral("#526879"), 0, 1, 2, 1, 1),
        tile(QStringLiteral("GitHub"), QStringLiteral("代码与项目"), QStringLiteral("GH"),
             QStringLiteral("#384f66"), 0, 2, 2, 2, 1),
        tile(QStringLiteral("游戏"), QStringLiteral("继续上次体验"), QStringLiteral("✦"),
             QStringLiteral("#76549a"), 0, 4, 1, 2, 2),

        tile(QStringLiteral("视频"), QStringLiteral("继续观看"), QStringLiteral("▶"),
             QStringLiteral("#864f85"), 1, 0, 0, 2, 2),
        tile(QStringLiteral("控制中心"), QStringLiteral("快速设置"), QStringLiteral("☼"),
             QStringLiteral("#287e98"), 1, 2, 0, 2, 1),
        tile(QStringLiteral("便笺"), QStringLiteral("今天的想法"), QStringLiteral("✎"),
             QStringLiteral("#96742d"), 1, 4, 0, 2, 1),
        tile(QStringLiteral("相机"), QStringLiteral("捕捉此刻"), QStringLiteral("◉"),
             QStringLiteral("#417764"), 1, 2, 1, 1, 1),
        tile(QStringLiteral("商店"), QStringLiteral("探索应用"), QStringLiteral("▣"),
             QStringLiteral("#187ba2"), 1, 3, 1, 1, 1),
        tile(QStringLiteral("阅读"), QStringLiteral("最近打开"), QStringLiteral("▤"),
             QStringLiteral("#846b42"), 1, 4, 1, 2, 2),
        tile(QStringLiteral("联系人"), QStringLiteral("常用联系人"), QStringLiteral("☺"),
             QStringLiteral("#a54d68"), 1, 0, 2, 1, 1),
        tile(QStringLiteral("文件"), QStringLiteral("浏览文件"), QStringLiteral("▰"),
             QStringLiteral("#3d6792"), 1, 1, 2, 1, 1),
        tile(QStringLiteral("桌面模式"), QStringLiteral("已准备就绪"), QStringLiteral("▦"),
             QStringLiteral("#316b82"), 1, 2, 2, 2, 1),
    };
}

bool TileStore::layoutIsValid(int editedIndex, const QVariantMap &candidate) const
{
    const int page = candidate.value(QStringLiteral("page")).toInt();
    const int column = candidate.value(QStringLiteral("column")).toInt();
    const int row = candidate.value(QStringLiteral("row")).toInt();
    const int columns = candidate.value(QStringLiteral("columns")).toInt();
    const int rows = candidate.value(QStringLiteral("rows")).toInt();

    if (page < 0 || page > 1 || column < 0 || row < 0
        || columns < 1 || columns > GridColumns || rows < 1 || rows > GridRows
        || column + columns > GridColumns || row + rows > GridRows) {
        return false;
    }

    for (qsizetype index = 0; index < m_tiles.size(); ++index) {
        if (index == editedIndex) {
            continue;
        }
        if (intersects(candidate, m_tiles.at(index).toMap())) {
            return false;
        }
    }
    return true;
}

bool TileStore::arrangeCollisions(QVariantList *tiles,
                                  int fixedIndex,
                                  int vacancyColumn,
                                  int vacancyRow) const
{
    if (!tiles || fixedIndex < 0 || fixedIndex >= tiles->size()) {
        return false;
    }

    const QVariantMap fixed = tiles->at(fixedIndex).toMap();
    std::vector<int> displaced;
    for (qsizetype index = 0; index < tiles->size(); ++index) {
        if (index != fixedIndex && intersects(fixed, tiles->at(index).toMap())) {
            displaced.push_back(static_cast<int>(index));
        }
    }
    std::sort(displaced.begin(), displaced.end(), [&](int left, int right) {
        const QVariantMap leftTile = tiles->at(left).toMap();
        const QVariantMap rightTile = tiles->at(right).toMap();
        return std::tuple(gridDistance(leftTile,
                                       fixed.value(QStringLiteral("column")).toInt(),
                                       fixed.value(QStringLiteral("row")).toInt()),
                          leftTile.value(QStringLiteral("row")).toInt(),
                          leftTile.value(QStringLiteral("column")).toInt())
            < std::tuple(gridDistance(rightTile,
                                      fixed.value(QStringLiteral("column")).toInt(),
                                      fixed.value(QStringLiteral("row")).toInt()),
                         rightTile.value(QStringLiteral("row")).toInt(),
                         rightTile.value(QStringLiteral("column")).toInt());
    });

    std::vector<bool> isDisplaced(static_cast<size_t>(tiles->size()), false);
    std::vector<bool> isPlaced(static_cast<size_t>(tiles->size()), false);
    for (const int index : displaced) {
        isDisplaced[static_cast<size_t>(index)] = true;
    }

    for (const int index : displaced) {
        const QVariantMap moving = tiles->at(index).toMap();
        const int columns = moving.value(QStringLiteral("columns")).toInt();
        const int rows = moving.value(QStringLiteral("rows")).toInt();
        const int oldColumn = moving.value(QStringLiteral("column")).toInt();
        const int oldRow = moving.value(QStringLiteral("row")).toInt();
        std::optional<std::tuple<int, int, int, int, int>> bestKey;
        std::optional<QPair<int, int>> bestPosition;

        for (int row = 0; row <= GridRows - rows; ++row) {
            for (int column = 0; column <= GridColumns - columns; ++column) {
                QVariantMap candidate = moving;
                candidate.insert(QStringLiteral("column"), column);
                candidate.insert(QStringLiteral("row"), row);
                bool occupied = false;
                for (qsizetype other = 0; other < tiles->size(); ++other) {
                    if (other == index
                        || (isDisplaced[static_cast<size_t>(other)]
                            && !isPlaced[static_cast<size_t>(other)])) {
                        continue;
                    }
                    if (intersects(candidate, tiles->at(other).toMap())) {
                        occupied = true;
                        break;
                    }
                }
                if (occupied) {
                    continue;
                }

                const auto key = std::tuple(
                    qAbs(column - oldColumn) + qAbs(row - oldRow),
                    qAbs(column - vacancyColumn) + qAbs(row - vacancyRow),
                    qAbs(row - oldRow),
                    row,
                    column);
                if (!bestKey || key < *bestKey) {
                    bestKey = key;
                    bestPosition = qMakePair(column, row);
                }
            }
        }

        if (!bestPosition) {
            return false;
        }

        QVariantMap updated = moving;
        updated.insert(QStringLiteral("column"), bestPosition->first);
        updated.insert(QStringLiteral("row"), bestPosition->second);
        (*tiles)[index] = updated;
        isPlaced[static_cast<size_t>(index)] = true;
    }

    return true;
}

void TileStore::publishTiles(const QVariantList &tiles)
{
    for (qsizetype index = 0; index < tiles.size(); ++index) {
        m_tileModel.updateTile(index, tiles.at(index).toMap());
    }
    emit tilesChanged();
}

bool TileStore::beginTileEdit(int tileIndex)
{
    if (tileIndex < 0 || tileIndex >= m_tiles.size()) {
        emit operationFailed(QStringLiteral("找不到要编辑的磁贴。"));
        return false;
    }
    if (m_editIndex >= 0) {
        cancelTileEdit();
    }
    m_editIndex = tileIndex;
    m_editSnapshot = m_tiles;
    m_editChanged = false;
    return true;
}

bool TileStore::previewTilePlacement(int tileIndex,
                                     int page,
                                     int column,
                                     int row,
                                     int columns,
                                     int rows)
{
    if (m_editIndex != tileIndex || m_editSnapshot.size() != m_tiles.size()) {
        emit operationFailed(QStringLiteral("磁贴编辑状态已结束，请重新长按选择。"));
        return false;
    }
    if (page < 0 || page > 1 || column < 0 || row < 0
        || columns < 1 || columns > GridColumns || rows < 1 || rows > GridRows
        || column + columns > GridColumns || row + rows > GridRows) {
        return false;
    }

    QVariantList preview = m_editSnapshot;
    QVariantMap target = preview.at(tileIndex).toMap();
    const int vacancyColumn = target.value(QStringLiteral("column")).toInt();
    const int vacancyRow = target.value(QStringLiteral("row")).toInt();
    target.insert(QStringLiteral("page"), page);
    target.insert(QStringLiteral("column"), column);
    target.insert(QStringLiteral("row"), row);
    target.insert(QStringLiteral("columns"), columns);
    target.insert(QStringLiteral("rows"), rows);
    preview[tileIndex] = target;

    if (!arrangeCollisions(&preview, tileIndex, vacancyColumn, vacancyRow)) {
        return false;
    }

    m_editChanged = preview != m_editSnapshot;
    m_tiles = preview;
    publishTiles(m_tiles);
    return true;
}

bool TileStore::finishTileEdit()
{
    if (m_editIndex < 0) {
        return false;
    }
    const bool changed = m_editChanged;
    if (!changed) {
        m_editIndex = -1;
        m_editSnapshot.clear();
        m_editChanged = false;
        return true;
    }
    if (save()) {
        m_editIndex = -1;
        m_editSnapshot.clear();
        m_editChanged = false;
        return true;
    }
    m_tiles = m_editSnapshot;
    m_editIndex = -1;
    m_editSnapshot.clear();
    m_editChanged = false;
    publishTiles(m_tiles);
    return false;
}

void TileStore::cancelTileEdit()
{
    if (m_editIndex < 0) {
        return;
    }
    m_tiles = m_editSnapshot;
    m_editSnapshot.clear();
    m_editIndex = -1;
    m_editChanged = false;
    publishTiles(m_tiles);
}

bool TileStore::updateTile(int index, const QVariantMap &changes)
{
    if (index < 0 || index >= m_tiles.size()) {
        emit operationFailed(QStringLiteral("找不到要编辑的磁贴，请重新选择。"));
        return false;
    }

    QVariantMap updated = m_tiles.at(index).toMap();
    const QStringList editableKeys{
        QStringLiteral("title"),
        QStringLiteral("subtitle"),
        QStringLiteral("icon"),
        QStringLiteral("iconSource"),
        QStringLiteral("color"),
        QStringLiteral("gradientEnd"),
        QStringLiteral("gradientEnabled"),
        QStringLiteral("imageSource"),
        QStringLiteral("opacity"),
        QStringLiteral("radius"),
        QStringLiteral("shadowMode"),
        QStringLiteral("columns"),
        QStringLiteral("rows"),
        QStringLiteral("liveEnabled"),
        QStringLiteral("customContentMode"),
        QStringLiteral("customContentSource"),
        QStringLiteral("videoLoop"),
        QStringLiteral("cornerPreset"),
    };
    for (const QString &key : editableKeys) {
        if (changes.contains(key)) {
            updated.insert(key, changes.value(key));
        }
    }

    if (changes.contains(QStringLiteral("iconSource"))
        && !updated.value(QStringLiteral("iconSource")).toString().isEmpty()) {
        QVariantList layers = updated.value(QStringLiteral("layers")).toList();
        for (qsizetype index = 0; index < layers.size(); ++index) {
            QVariantMap layer = layers.at(index).toMap();
            if (!layer.value(QStringLiteral("autoColor")).toBool()) {
                continue;
            }
            if (!applyIconEdgeColors(&layer,
                                     updated.value(QStringLiteral("iconSource")).toString())) {
                emit operationFailed(QStringLiteral("无法读取图标边缘颜色，请选择一张有效的图片。"));
                return false;
            }
            layers[index] = layer;
        }
        updated.insert(QStringLiteral("layers"), layers);
    } else if (changes.contains(QStringLiteral("iconSource"))
               && updated.value(QStringLiteral("iconSource")).toString().isEmpty()) {
        QVariantList layers = updated.value(QStringLiteral("layers")).toList();
        for (qsizetype index = 0; index < layers.size(); ++index) {
            QVariantMap layer = layers.at(index).toMap();
            if (!layer.value(QStringLiteral("autoColor")).toBool()) {
                continue;
            }
            const QString color = layer.value(QStringLiteral("color")).toString();
            layer.insert(QStringLiteral("type"), QStringLiteral("solid"));
            layer.insert(QStringLiteral("endColor"), color);
            layer.insert(QStringLiteral("angle"), 0);
            layers[index] = layer;
        }
        updated.insert(QStringLiteral("layers"), layers);
    }

    const QString title = updated.value(QStringLiteral("title")).toString().trimmed();
    const QString subtitle = updated.value(QStringLiteral("subtitle")).toString().trimmed();
    const QString icon = updated.value(QStringLiteral("icon")).toString().trimmed();
    if (title.isEmpty() || title.size() > 32 || subtitle.size() > 80 || icon.size() > 8) {
        emit operationFailed(QStringLiteral("请填写有效的名称、说明和图标文字（名称最多 32 字，说明 80 字，图标 8 字）。"));
        return false;
    }

    const QColor color(updated.value(QStringLiteral("color")).toString());
    const QColor gradientEnd(updated.value(QStringLiteral("gradientEnd")).toString());
    const bool gradientEnabled = updated.value(QStringLiteral("gradientEnabled")).toBool();
    if (!color.isValid() || (gradientEnabled && !gradientEnd.isValid())) {
        emit operationFailed(QStringLiteral("颜色格式无效，请输入有效的十六进制颜色。"));
        return false;
    }
    updated.insert(QStringLiteral("color"), color.name(QColor::HexRgb));
    updated.insert(QStringLiteral("gradientEnd"),
                   gradientEnabled ? gradientEnd.name(QColor::HexRgb) : color.name(QColor::HexRgb));

    const double opacity = updated.value(QStringLiteral("opacity")).toDouble();
    const int radius = updated.value(QStringLiteral("radius")).toInt();
    const QString shadowMode = updated.value(QStringLiteral("shadowMode")).toString();
    if (opacity < 0.15 || opacity > 1.0 || radius < 0 || radius > 48
        || (shadowMode != QStringLiteral("none")
            && shadowMode != QStringLiteral("outer")
            && shadowMode != QStringLiteral("inset")
            && shadowMode != QStringLiteral("both"))) {
        emit operationFailed(QStringLiteral("磁贴外观设置超出允许范围，请检查后重试。"));
        return false;
    }

    const QString cornerPreset = updated.value(QStringLiteral("cornerPreset")).toString();
    const QStringList cornerPresets{
        QStringLiteral("square"),
        QStringLiteral("micro"),
        QStringLiteral("natural"),
        QStringLiteral("medium"),
        QStringLiteral("high"),
        QStringLiteral("circle"),
    };
    if (!cornerPresets.contains(cornerPreset)) {
        emit operationFailed(QStringLiteral("请选择列表中的磁贴曲率。"));
        return false;
    }

    QString contentMode = updated.value(QStringLiteral("customContentMode")).toString();
    if (contentMode != QStringLiteral("none")
        && contentMode != QStringLiteral("image")
        && contentMode != QStringLiteral("video")) {
        emit operationFailed(QStringLiteral("自定义内容只支持图片或视频。"));
        return false;
    }

    if (changes.contains(QStringLiteral("liveEnabled"))
        && updated.value(QStringLiteral("liveEnabled")).toBool()) {
        updated.insert(QStringLiteral("customContentMode"), QStringLiteral("none"));
        updated.insert(QStringLiteral("customContentSource"), QString());
    } else if (changes.contains(QStringLiteral("customContentMode"))
               && contentMode != QStringLiteral("none")) {
        updated.insert(QStringLiteral("liveEnabled"), false);
    }
    contentMode = updated.value(QStringLiteral("customContentMode")).toString();

    const bool hadCustomMedia = m_tiles.at(index).toMap()
                                    .value(QStringLiteral("mediaContentActive")).toBool();
    const bool hasCustomMedia = contentMode != QStringLiteral("none");
    if (hasCustomMedia != hadCustomMedia) {
        QVariantList layers = updated.value(QStringLiteral("layers")).toList();
        if (!layers.isEmpty()) {
            QVariantMap firstLayer = layers.first().toMap();
            firstLayer.insert(QStringLiteral("opacity"), hasCustomMedia ? 0.25 : 1.0);
            layers[0] = firstLayer;
            updated.insert(QStringLiteral("layers"), layers);
        }
        updated.insert(QStringLiteral("mediaContentActive"), hasCustomMedia);
    }

    return commitTile(index, updated);
}

bool TileStore::commitTile(int index, const QVariantMap &updated)
{
    if (!layoutIsValid(index, updated)) {
        emit operationFailed(QStringLiteral("这个尺寸会与其他磁贴重叠，请换一个尺寸再试。"));
        return false;
    }

    const QVariant previous = m_tiles.at(index);
    m_tiles[index] = updated;
    if (!save()) {
        m_tiles[index] = previous;
        return false;
    }
    m_tileModel.updateTile(index, updated);
    emit tilesChanged();
    return true;
}

bool TileStore::addLayer(int tileIndex, const QString &type)
{
    if (tileIndex < 0 || tileIndex >= m_tiles.size()
        || (type != QStringLiteral("solid") && type != QStringLiteral("gradient"))) {
        emit operationFailed(QStringLiteral("无法添加图层：请先选择单色或渐变，并确认磁贴有效。"));
        return false;
    }

    QVariantMap updated = m_tiles.at(tileIndex).toMap();
    QVariantList layers = updated.value(QStringLiteral("layers")).toList();
    const QVariantMap topLayer = layers.isEmpty() ? QVariantMap{} : layers.constLast().toMap();
    const QString color = topLayer.value(QStringLiteral("color"), QStringLiteral("#ffffff")).toString();
    layers.append(QVariantMap{
        {QStringLiteral("type"), type},
        {QStringLiteral("color"), color},
        {QStringLiteral("endColor"), QStringLiteral("#087da5")},
        {QStringLiteral("angle"), 0},
        {QStringLiteral("opacity"), 1.0},
        {QStringLiteral("saturation"), 1.0},
        {QStringLiteral("brightness"), 1.0},
        {QStringLiteral("autoColor"), false},
    });
    updated.insert(QStringLiteral("layers"), layers);
    return commitTile(tileIndex, updated);
}

bool TileStore::updateLayer(int tileIndex, int layerIndex, const QVariantMap &changes)
{
    if (tileIndex < 0 || tileIndex >= m_tiles.size()) {
        emit operationFailed(QStringLiteral("找不到要编辑的磁贴。"));
        return false;
    }

    QVariantMap updated = m_tiles.at(tileIndex).toMap();
    QVariantList layers = updated.value(QStringLiteral("layers")).toList();
    if (layerIndex < 0 || layerIndex >= layers.size()) {
        emit operationFailed(QStringLiteral("找不到选中的颜色图层。"));
        return false;
    }

    QVariantMap layer = layers.at(layerIndex).toMap();
    const QStringList editableKeys{
        QStringLiteral("color"),
        QStringLiteral("endColor"),
        QStringLiteral("angle"),
        QStringLiteral("opacity"),
        QStringLiteral("saturation"),
        QStringLiteral("brightness"),
        QStringLiteral("autoColor"),
    };
    for (const QString &key : editableKeys) {
        if (changes.contains(key)) {
            layer.insert(key, changes.value(key));
        }
    }

    const QString layerType = layer.value(QStringLiteral("type")).toString();
    QColor color(layer.value(QStringLiteral("color")).toString());
    QColor endColor(layer.value(QStringLiteral("endColor")).toString());
    const double opacity = layer.value(QStringLiteral("opacity")).toDouble();
    const double saturation = layer.value(QStringLiteral("saturation")).toDouble();
    const double brightness = layer.value(QStringLiteral("brightness")).toDouble();
    const int angle = layer.value(QStringLiteral("angle")).toInt();
    if ((layerType != QStringLiteral("solid") && layerType != QStringLiteral("gradient"))
        || !color.isValid() || (layerType == QStringLiteral("gradient") && !endColor.isValid())
        || opacity < 0.0 || opacity > 1.0 || saturation < 0.0 || saturation > 1.0
        || brightness < 0.0 || brightness > 1.0 || angle < 0 || angle > 359) {
        emit operationFailed(QStringLiteral("图层颜色、角度或透明度无效。"));
        return false;
    }

    if (changes.value(QStringLiteral("autoColor"), false).toBool()) {
        const QString iconSource = m_tiles.at(tileIndex).toMap()
                                       .value(QStringLiteral("iconSource")).toString();
        if (!applyIconEdgeColors(&layer, iconSource)) {
            emit operationFailed(QStringLiteral("自动取色需要先为这块磁贴选择图标图片。"));
            return false;
        }
        color = QColor(layer.value(QStringLiteral("color")).toString());
        endColor = QColor(layer.value(QStringLiteral("endColor")).toString());
    } else if (changes.contains(QStringLiteral("color"))
               || changes.contains(QStringLiteral("endColor"))) {
        layer.insert(QStringLiteral("autoColor"), false);
    }

    layer.insert(QStringLiteral("color"), color.name(QColor::HexRgb));
    if (endColor.isValid()) {
        layer.insert(QStringLiteral("endColor"), endColor.name(QColor::HexRgb));
    }
    layers[layerIndex] = layer;
    updated.insert(QStringLiteral("layers"), layers);
    updated.insert(QStringLiteral("color"), color.name(QColor::HexRgb));
    return commitTile(tileIndex, updated);
}

bool TileStore::removeLayer(int tileIndex, int layerIndex)
{
    if (tileIndex < 0 || tileIndex >= m_tiles.size()) {
        emit operationFailed(QStringLiteral("找不到要编辑的磁贴。"));
        return false;
    }

    QVariantMap updated = m_tiles.at(tileIndex).toMap();
    QVariantList layers = updated.value(QStringLiteral("layers")).toList();
    if (layerIndex < 0 || layerIndex >= layers.size() || layers.size() <= 1) {
        emit operationFailed(QStringLiteral("至少保留一个背景图层。"));
        return false;
    }
    layers.removeAt(layerIndex);
    updated.insert(QStringLiteral("layers"), layers);
    updated.insert(QStringLiteral("color"),
                   layers.constFirst().toMap().value(QStringLiteral("color")));
    return commitTile(tileIndex, updated);
}

bool TileStore::moveLayer(int tileIndex, int fromIndex, int toIndex)
{
    if (tileIndex < 0 || tileIndex >= m_tiles.size()) {
        emit operationFailed(QStringLiteral("找不到要编辑的磁贴。"));
        return false;
    }

    QVariantMap updated = m_tiles.at(tileIndex).toMap();
    QVariantList layers = updated.value(QStringLiteral("layers")).toList();
    if (fromIndex < 0 || fromIndex >= layers.size()
        || toIndex < 0 || toIndex >= layers.size()) {
        emit operationFailed(QStringLiteral("图层位置无效，无法调整顺序。"));
        return false;
    }
    if (fromIndex == toIndex) {
        return true;
    }

    const QVariant layer = layers.takeAt(fromIndex);
    layers.insert(toIndex, layer);
    updated.insert(QStringLiteral("layers"), layers);
    return commitTile(tileIndex, updated);
}

void TileStore::resetTile(int index)
{
    const QVariantList defaults = defaultTiles();
    if (index < 0 || index >= defaults.size()) {
        emit operationFailed(QStringLiteral("找不到要重置的磁贴，请重新选择。"));
        return;
    }

    QVariantMap candidate = defaults.at(index).toMap();
    if (!layoutIsValid(index, candidate)) {
        emit operationFailed(QStringLiteral("无法重置：原始位置已被其他磁贴占用。"));
        return;
    }

    const QVariant previous = m_tiles.at(index);
    m_tiles[index] = candidate;
    if (!save()) {
        m_tiles[index] = previous;
        return;
    }
    m_tileModel.updateTile(index, candidate);
    emit tilesChanged();
}

bool TileStore::save()
{
    m_settings.setValue(QStringLiteral("tiles"), m_tiles);
    m_settings.setValue(QStringLiteral("tileLayoutVersion"), 2);
    if (m_settings.status() != QSettings::NoError) {
        emit operationFailed(QStringLiteral("磁贴设置没有保存成功，请检查用户配置目录的权限。"));
        return false;
    }
    m_saveTimer.start();
    return true;
}
